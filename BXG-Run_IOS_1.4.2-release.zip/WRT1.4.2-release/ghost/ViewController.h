//
//  ViewController.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 9..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import <UIKit/UIKit.h>

#include <math.h>

#define DEGREE_TO_RADIAN(d) (M_PI*d/180.0)

#define ANIMATION_ID_HIDE_STATUSBAR             @"hideStatusBar"
#define ANIMATION_ID_SHOW_STATUSBAR_PORTRAIT    @"showStatusBarPortrait"
#define ANIMATION_ID_SHOW_STATUSBAR_UPSIDE_DOWN @"showStatusBarUpsideDown"
#define ANIMATION_ID_SHOW_STATUSBAR_LEFT        @"showStatusBarLeft"
#define ANIMATION_ID_SHOW_STATUSBAR_RIGHT       @"showStatusBarRight"

#define ANIMATION_ID_ROTATE_VIEW_RIGHT          @"rotateViewRight"
#define ANIMATION_ID_ROTATE_VIEW_LEFT           @"rotateViewLeft"
#define ANIMATION_ID_ROTATE_VIEW_PORTRAIT       @"rotateViewPortrait"
#define ANIMATION_ID_ROTATE_VIEW_UPSIDEDOWN     @"rotateViewUpsideDown"

#define NOTI_ID_VISIBLE_STATUSBAR   @"Noti_visibleStatusBar"
#define NOTI_ID_ROTATE_VIEW         @"Noti_rotateView"

#define NOTI_KEY_STATUSBAR      @"hide"
#define NOTI_KEY_ROTATE_VIEW    @"degree"
#define NOTI_KEY_CBNAME         @"cbname"

@interface ViewController : UIViewController

@property (strong, nonatomic) UIWebView* m_webview;
@property (strong, nonatomic) NSArray* m_supportedOrientation;

+ (void)setWebviewOrientation:(UIInterfaceOrientation)orientation;
+ (void)setMainviewOrientation:(UIInterfaceOrientation)orientation;
+ (UIInterfaceOrientation)getWebviewOrientation;
+ (UIInterfaceOrientation)getMainviewOrientation;

- (void)receiveControllerNotification:(NSNotification*)notification;

@end
