//
//  ViewController.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 9..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h" // 이걸 넣지 않으면 didRotateFromInterfaceOrientation 가 호출되지 않는다.

@implementation ViewController

@synthesize m_webview;
@synthesize m_supportedOrientation;

static UIInterfaceOrientation STATIC_WEBVIEW_ORIENTATION;
static UIInterfaceOrientation STATIC_MAIN_VIEW_ORIENTATION;

#pragma mark -
#pragma mark AllocDealloc
- (id)init {
    if((self=[super init])) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveControllerNotification:) name:NOTI_ID_VISIBLE_STATUSBAR object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveControllerNotification:) name:NOTI_ID_ROTATE_VIEW object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

#pragma mark -
#pragma mark StaticFunction
+ (void)setWebviewOrientation:(UIInterfaceOrientation)orientation { STATIC_WEBVIEW_ORIENTATION = orientation; }
+ (void)setMainviewOrientation:(UIInterfaceOrientation)orientation { STATIC_MAIN_VIEW_ORIENTATION = orientation; }
+ (UIInterfaceOrientation)getWebviewOrientation { return STATIC_WEBVIEW_ORIENTATION; }
+ (UIInterfaceOrientation)getMainviewOrientation { return STATIC_MAIN_VIEW_ORIENTATION; }

#pragma mark -
#pragma mark Notifications
- (void)receiveControllerNotification:(NSNotification *)notification {
    NSDictionary* userInfo = [notification userInfo];
    
    if([[notification name] isEqualToString:NOTI_ID_VISIBLE_STATUSBAR]) {
        if([[userInfo objectForKey:NOTI_KEY_STATUSBAR] boolValue]) {
            [UIView beginAnimations:ANIMATION_ID_HIDE_STATUSBAR context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
            [UIView setAnimationDuration:0.35];
            CGRect contentRect = CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height); 
            [[self view] setFrame:contentRect];
            [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
            [UIView setAnimationDidStopSelector:@selector(animationDone:finished:context:)];
            [UIView setAnimationDelegate:self];
            [UIView commitAnimations];
        } else {
            [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
            UIInterfaceOrientation statusBarOrientation = [UIApplication sharedApplication].statusBarOrientation;
            CGRect statusBarFrame = [[UIApplication sharedApplication] statusBarFrame];
            switch(statusBarOrientation) {
                case UIInterfaceOrientationPortraitUpsideDown:
                    [UIView beginAnimations:ANIMATION_ID_SHOW_STATUSBAR_UPSIDE_DOWN context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                    [UIView setAnimationDuration:0.35];
                    self.view.frame = CGRectMake(0, -statusBarFrame.size.height, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                    break;
                case UIInterfaceOrientationLandscapeLeft:
                    [UIView beginAnimations:ANIMATION_ID_SHOW_STATUSBAR_LEFT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                    [UIView setAnimationDuration:0.35];
                    self.view.frame = CGRectMake(statusBarFrame.size.width, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                    break;
                case UIInterfaceOrientationLandscapeRight:
                    [UIView beginAnimations:ANIMATION_ID_SHOW_STATUSBAR_RIGHT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                    [UIView setAnimationDuration:0.35];
                    self.view.frame = CGRectMake(-statusBarFrame.size.width, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                    break;
                case UIInterfaceOrientationPortrait:
                default:
                    [UIView beginAnimations:ANIMATION_ID_SHOW_STATUSBAR_PORTRAIT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                    [UIView setAnimationDuration:0.35];
                    self.view.frame = CGRectMake(0, statusBarFrame.size.height, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                    break;
            }
            [UIView setAnimationDidStopSelector:@selector(animationDone:finished:context:)];
            [UIView setAnimationDelegate:self];
            [UIView commitAnimations];
        }
    } else if([[notification name] isEqualToString:NOTI_ID_ROTATE_VIEW]) {
        int degree = [[userInfo objectForKey:NOTI_KEY_ROTATE_VIEW] intValue];
        
        /*
        // status bar는 돌리지 않는다.
        CGRect statusBarFrame = [[UIApplication sharedApplication] statusBarFrame];
        BOOL isStatusBar = NO;
        switch([ViewController getWebviewOrientation]) {
            case 1: // UIInterfaceOrientationPortrait
            case 2: // UIInterfaceOrientationPortraitUpsideDown
                if(statusBarFrame.size.height > 0) { isStatusBar=YES; }
                break;
            case 4: // UIInterfaceOrientationLandscapeLeft
            case 3: // UIInterfaceOrientationLandscapeRight
            default:
                if(statusBarFrame.size.width > 0) { isStatusBar=YES; }
                break;
        }
        */
        
        CGAffineTransform transform = CGAffineTransformMakeRotation(DEGREE_TO_RADIAN(degree));
        CGRect viewRect;
        
        UIInterfaceOrientation statusBarNewOrientation;
        switch(degree) {
            case 90: // UIInterfaceOrientationLandscapeRight
                viewRect = CGRectMake(UIScreen.mainScreen.bounds.origin.x, UIScreen.mainScreen.bounds.origin.y, 
                        UIScreen.mainScreen.bounds.size.height, UIScreen.mainScreen.bounds.size.width);
                statusBarNewOrientation = UIInterfaceOrientationLandscapeRight;
                
//                [[UIApplication sharedApplication] setStatusBarOrientation:statusBarNewOrientation];
                
                [UIView beginAnimations:ANIMATION_ID_ROTATE_VIEW_RIGHT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                break;
            case -90: // UIInterfaceOrientationLandscapeLeft
                viewRect = CGRectMake(UIScreen.mainScreen.bounds.origin.x, UIScreen.mainScreen.bounds.origin.y, 
                        UIScreen.mainScreen.bounds.size.height, UIScreen.mainScreen.bounds.size.width);
                statusBarNewOrientation = UIInterfaceOrientationLandscapeLeft;
                
//                [[UIApplication sharedApplication] setStatusBarOrientation:statusBarNewOrientation];
                
                [UIView beginAnimations:ANIMATION_ID_ROTATE_VIEW_LEFT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                break;
            case 180: // UIInterfaceOrientationPortraitUpsideDown
                viewRect = CGRectMake(UIScreen.mainScreen.bounds.origin.x, UIScreen.mainScreen.bounds.origin.y, 
                        UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                statusBarNewOrientation = UIInterfaceOrientationPortraitUpsideDown;
                
//                [[UIApplication sharedApplication] setStatusBarOrientation:statusBarNewOrientation];
                
                [UIView beginAnimations:ANIMATION_ID_ROTATE_VIEW_UPSIDEDOWN context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                break;
            case 0: // UIInterfaceOrientationPortrait
            default:
                viewRect = CGRectMake(UIScreen.mainScreen.bounds.origin.x, UIScreen.mainScreen.bounds.origin.y, 
                        UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height);
                statusBarNewOrientation = UIInterfaceOrientationPortrait;
                
//                [[UIApplication sharedApplication] setStatusBarOrientation:statusBarNewOrientation];
                
                [UIView beginAnimations:ANIMATION_ID_ROTATE_VIEW_PORTRAIT context:[userInfo objectForKey:NOTI_KEY_CBNAME]];
                break;
        }
        
        [UIView setAnimationDuration:0.35];
        [self.view setTransform:transform];
        
        [self.view setBounds:viewRect];
//        [[UIApplication sharedApplication] setStatusBarOrientation:statusBarNewOrientation];
        
        [UIView setAnimationDidStopSelector:@selector(animationDone:finished:context:)];
        [UIView setAnimationDelegate:self];
        [UIView commitAnimations];
    }
}

- (void)animationDone:(NSString *)animationID finished:(BOOL)finished context:(void *)context {
    CGRect statusBar = [[UIApplication sharedApplication] statusBarFrame];
    
    NSString* jsStr = nil;
    if([animationID isEqualToString:ANIMATION_ID_HIDE_STATUSBAR]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
    
    } else if([animationID isEqualToString:ANIMATION_ID_SHOW_STATUSBAR_PORTRAIT]) {
        self.view.frame = CGRectMake(0, statusBar.size.height, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height-statusBar.size.height);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        
    } else if([animationID isEqualToString:ANIMATION_ID_SHOW_STATUSBAR_UPSIDE_DOWN]) {
        self.view.frame = CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height-statusBar.size.height);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        
    } else if([animationID isEqualToString:ANIMATION_ID_SHOW_STATUSBAR_LEFT]) {
        self.view.frame = CGRectMake(statusBar.size.width, 0, UIScreen.mainScreen.bounds.size.width-statusBar.size.width, UIScreen.mainScreen.bounds.size.height);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        
    } else if([animationID isEqualToString:ANIMATION_ID_SHOW_STATUSBAR_RIGHT]) {
        self.view.frame = CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width-statusBar.size.width, UIScreen.mainScreen.bounds.size.height);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        
    } else if([animationID isEqualToString:ANIMATION_ID_ROTATE_VIEW_RIGHT]) {
        [ViewController setWebviewOrientation:3];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [3], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
    
    } else if([animationID isEqualToString:ANIMATION_ID_ROTATE_VIEW_LEFT]) {
        [ViewController setWebviewOrientation:4];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [4], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
    
    } else if([animationID isEqualToString:ANIMATION_ID_ROTATE_VIEW_UPSIDEDOWN]) {
        [ViewController setWebviewOrientation:2];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [2], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
    
    } else if([animationID isEqualToString:ANIMATION_ID_ROTATE_VIEW_PORTRAIT]) {
        [ViewController setWebviewOrientation:1];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [1], false);", context];
        [self.m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        
    }
}

#pragma mark -
#pragma mark OrientationRotate
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    int degree = 0;
    switch(toInterfaceOrientation) {
        case UIInterfaceOrientationPortraitUpsideDown: degree=180; break;
        case UIInterfaceOrientationLandscapeLeft: degree=-90; break;
        case UIInterfaceOrientationLandscapeRight: degree=90; break;
        case UIInterfaceOrientationPortrait:
        default: break;
    }
    
    // javascript 내에서 shouldRotateToOrientation 함수를 정의 하는 것에 따라 화면 회전을 컨트롤 할 수 있다.
    NSString* jsRot = [NSString stringWithFormat:@"__rotateOrientationControl(%d);", degree];
    NSString* rot = [m_webview stringByEvaluatingJavaScriptFromString:jsRot];
    if([rot length] > 0) {
        [ViewController setWebviewOrientation:toInterfaceOrientation];
        [ViewController setMainviewOrientation:toInterfaceOrientation];
        return [rot boolValue];
    }
    
    BOOL autoRotate = [m_supportedOrientation count]>0;
    if(autoRotate) {
        if([self.m_supportedOrientation containsObject:[NSNumber numberWithInt:toInterfaceOrientation]]) {
            [ViewController setWebviewOrientation:toInterfaceOrientation];
            [ViewController setMainviewOrientation:toInterfaceOrientation];
            return YES;
        }
    }
    return NO;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    // window.orientation에 현재 각도를 세팅하고
    // window.onorientationchange 이벤트를 발생 시킨다.
    // __defineGetter__ 가 firefox에서는 deprecate 되었는데 safari는 언제까지 가능할지 모르겠다.
    // WRT에 포함된 webview 에서 이벤트를 자동 발생 시켜 주기 때문에, 수동으로 이벤트를 발생시키지 않는다.
    // 만일 이벤트가 발생되지 않는다면 아래 주석 풀고 수동으로 발생 시키자.
    
    //int degree = 0;
    //switch(self.interfaceOrientation) {
    //    case UIInterfaceOrientationPortrait: degree=0; break;
    //    case UIInterfaceOrientationPortraitUpsideDown: degree = 180; break;
    //    case UIInterfaceOrientationLandscapeLeft: degree=-90; break;
    //    case UIInterfaceOrientationLandscapeRight: degree = 90; break;
    //    default: degree=0; break;
    //}
    
    //NSString* jsRot = [NSString stringWithFormat:@"window.__defineGetter__('orientation',function(){return %d;});window.onorientationchange();",degree];
    //[m_webview stringByEvaluatingJavaScriptFromString:jsRot];
}

@end
