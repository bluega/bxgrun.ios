//
//  AppDelegate.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 9..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommandPool.h"

#import "lib/JSONFragment/JSON.h"

// config.plist의 key 값
#define CONFIG_KEY_VERSION                  @"version"
#define CONFIG_KEY_LOCKSCREEN               @"lockScreen"
#define CONFIG_KEY_STARTPAGE                @"startPage"
#define CONFIG_KEY_HTMLDIR                  @"htmlDirectory"
#define CONFIG_KEY_ACTIVITY_INDICATOR_STYLE @"activityIndicatorStyle"
#define CONFIG_KEY_MEMORY_CACHE_SIZE        @"memCacheSize"
#define CONFIG_KEY_DISK_CACHE_SIZE          @"diskCacheSize"
#define CONFIG_KEY_PREVENT_PAGE_SCROLL      @"preventPageScroll"
#define CONFIG_KEY_DISK_QUOTA               @"diskQuota"
#define CONFIG_KEY_DISK_QUOTA_REVISON_THRE  @"diskQuotaRevisonThresholds"
#ifdef SUPPORT_BXGRNIF
#define CONFIG_KEY_BXGRNIF                  @"Bxgrnif"
#define CONFIG_KEY_BXGRNIF_CACHEHOME        @"cacheHome"
#define CONFIG_KEY_BXGRNIF_SAVEDIR          @"saveDir"
#define CONFIG_KEY_BXGRNIF_SHAREPARENT      @"shareParent"
#define CONFIG_KEY_BXGRNIF_SHAREDIR         @"shareDir"
#endif

// config.plist의 activityIndicatorStyle에 사용되는 값
#define CONFIG_VAL_ACTIVITY_INDICATOR_WHITE         @"white"
#define CONFIG_VAL_ACTIVITY_INDICATOR_WHITE_LARGE   @"whiteLarge"
#define CONFIG_VAL_ACTIVITY_INDICATOR_GRAY          @"gray"
#define CONFIG_VAL_ACTIVITY_INDICATOR_NONE          @"none"

#define FILE_NAME_UUID              @".UUID"
#define FILE_NAME_DISK_LIMIT_SPACE  @".DISK_LIMIT_SPACE"
#define FILE_NAME_DISK_USAGE_SPACE  @".DISK_USAGE_SPACE"

#define DEV_KEY_NAME            @"DevName"
#define DEV_KEY_SYS_NAME        @"DevSysName"
#define DEV_KEY_SYS_VERSION     @"DevSysVersion"
#define DEV_KEY_MODEL           @"DevModel"
#define DEV_KEY_LOCALIZE_MODEL  @"DevLocalizedModel"
#define DEV_KEY_UUID            @"DevUUID"

// ios orientation과 매핑이 되어야 한다. OS가 업데이트 되면 변경되지는 아닌지 체크 필요한 부분.
#define ROT_UIInterfaceOrientationPortrait              @"UIInterfaceOrientationPortrait"
#define ROT_UIInterfaceOrientationPortraitUpsideDown    @"UIInterfaceOrientationPortraitUpsideDown"
#define ROT_UIInterfaceOrientationLandscapeLeft         @"UIInterfaceOrientationLandscapeLeft"
#define ROT_UIInterfaceOrientationLandscapeRight        @"UIInterfaceOrientationLandscapeRight";

// WRT에서 지원하는 기능 셋 갯수
// 1. Console
#define COUNT_OF_WRT_FUNCTION  1


@class ViewController;

@interface AppDelegate : UIResponder <
        UIApplicationDelegate,
        UIWebViewDelegate> {
    BOOL m_appFirstActivate;
}

@property (strong, nonatomic) UIWindow* m_window;
@property (retain, nonatomic) NSDictionary* m_config;
@property (retain, nonatomic) UIWebView* m_webView;
@property (retain, nonatomic) UIImageView* m_imageView;
@property (retain, nonatomic) ViewController* m_viewController;
@property (retain, nonatomic) UIActivityIndicatorView* m_activityView;
@property (retain, nonatomic) NSMutableArray* m_loadingKind;
@property (retain, nonatomic) NSDictionary* m_properties;
@property (retain, nonatomic) CommandPool* m_commandPool;
@property (retain, nonatomic) NSMutableDictionary* m_commandObjects;
@property (retain, nonatomic) NSMutableArray* m_rotateOrientation;
@property (retain, nonatomic) NSString* m_uuid;


+ (NSDictionary*)getPropertyList:(NSString*)plistName;
+ (NSString*)getPathForResourceFile:(NSString*)path with:(NSString*)wwwFolder;
+ (void)showNetworkActivityIndicator:(BOOL)show;
+ (NSString*)getHtmlDirectory;
+ (NSString*)getApplicationPath;
+ (NSString*)getApplicationTmpPath;
#ifdef SUPPORT_BXGRNIF
+ (NSString*)getBxgrnifCacheHomePath;
+ (NSString*)getBxgrnifSavePath;
+ (NSString*)getBxgrnifSharePath;
+ (void)setRunPackageId:(NSString*)pkgId;
+ (NSString*)getRunPackageId;
+ (void)updateRunPackageId;
#endif
+ (void)setDiskUsageInformation;
+ (void)setQuotaAmout:(long long)amout withKind:(BOOL)flag;
+ (void)setDiskFreeAmount:(long long)amount;
+ (long long)getDiskFreeAmout;
+ (long long)getDiskLimitAmount;
+ (long long)getDiskUsageAmount;

- (NSString*)getUUID;
- (NSDictionary*)getDeviceProperties;
- (BOOL)exec:(Invoke*)cmd;
- (id)getClassInstance:(NSString*)className;
- (NSArray*)toNumberForOrientations:(NSArray*)orientations;


@end
