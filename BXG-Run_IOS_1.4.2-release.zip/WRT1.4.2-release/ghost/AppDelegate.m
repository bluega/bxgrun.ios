//
//  AppDelegate.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 9..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
#import "Command.h"

@implementation AppDelegate

@synthesize m_window = _window;
@synthesize m_config;
@synthesize m_webView;
@synthesize m_imageView;
@synthesize m_viewController;
@synthesize m_activityView;
@synthesize m_loadingKind;
@synthesize m_properties;
@synthesize m_commandPool;
@synthesize m_commandObjects;
@synthesize m_rotateOrientation;
@synthesize m_uuid;

static NSString* STATIC_HTML_DIRECTORY          = nil;
static NSString* STATIC_APPLICATION_PATH        = nil;
static NSString* STATIC_APPLICATION_TMP_PATH    = nil;
#ifdef SUPPORT_BXGRNIF
static NSString* STATIC_BXGRNIF_CACHE_HOME_PATH = nil;
static NSString* STATIC_BXGRNIF_SAVE_PATH       = nil;
static NSString* STATIC_BXGRNIF_SHARE_PATH      = nil;
static NSString* STATIC_RUN_PACKAGE_ID          = nil;
static NSString* STATIC_RUN_PACKAGE_ID_TMP      = nil;
#endif
static NSString* STATIC_DISK_LIMIT_AMOUT_PATH  = nil;
static NSString* STATIC_DISK_USAGE_AMOUT_PATH  = nil;

static long long STATIC_DISK_LIMIT_AMOUT        = 0;
static long long STATIC_DISK_FREE_AMOUT         = 0;
static long long STATIC_DISK_USAGE_AMOUT        = 0;
static long long STATIC_QUOTA_DEFINE_SIZE       = 0;
static int STATIC_QUOTA_REVISION_THRESHOLDS     = 0;
static int STATIC_QUOTA_REVISION_COUNT          = 0;
static NSLock* STATIC_QUOTA_LOCK                = nil;

#pragma mark -
#pragma mark Alloc Dealloc
- (id)init {
    if((self=[super init])) {
        m_commandObjects = [[NSMutableDictionary alloc] initWithCapacity:COUNT_OF_WRT_FUNCTION];
        STATIC_QUOTA_LOCK = [[NSLock alloc] init];
    }
    return self;
}

- (void)dealloc {
    [_window release];
    [m_config release];
    [m_webView release];
    [m_viewController release];
    if(m_activityView != nil) { [m_activityView release]; }
    [m_loadingKind release];
    [m_properties release];
    [m_commandPool release];
    [m_commandObjects release];
    [m_rotateOrientation release];
    [m_uuid release];
    [STATIC_DISK_LIMIT_AMOUT_PATH release];
    [STATIC_DISK_USAGE_AMOUT_PATH release];
    [STATIC_APPLICATION_TMP_PATH release];
#ifdef SUPPORT_BXGRNIF
    [STATIC_BXGRNIF_SAVE_PATH release];
    [STATIC_BXGRNIF_SHARE_PATH release];
    [STATIC_BXGRNIF_CACHE_HOME_PATH release];
    if(STATIC_RUN_PACKAGE_ID) { [STATIC_RUN_PACKAGE_ID release]; }
    if(STATIC_RUN_PACKAGE_ID_TMP) { [STATIC_RUN_PACKAGE_ID_TMP release]; }
#endif
    [STATIC_QUOTA_LOCK release];
    [STATIC_APPLICATION_PATH release];
    [super dealloc];
}

#pragma mark -
#pragma mark Static Function
+ (NSDictionary*)getPropertyList:(NSString*)plistName {
    NSString* err = nil;
    NSPropertyListFormat format;
    NSString* path = [[NSBundle mainBundle] pathForResource:plistName ofType:@"plist"];
    NSData* xmlData = [[NSFileManager defaultManager] contentsAtPath:path];
    NSDictionary* data = (NSDictionary*)[NSPropertyListSerialization
                propertyListFromData:xmlData 
                mutabilityOption:NSPropertyListMutableContainersAndLeaves 
                format:&format 
                errorDescription:&err];
    return data;
}

+ (NSString*)getPathForResourceFile:(NSString*)path with:(NSString*)wwwFolder {
    NSBundle* mainBundle = [NSBundle mainBundle];
    NSMutableArray* dirParts = [NSMutableArray arrayWithArray:[path componentsSeparatedByString:@"/"]];
    NSString* fname = [dirParts lastObject];
    [dirParts removeLastObject];
    
    NSString* dirStr = nil;
    if(wwwFolder != nil) {
        dirStr = [NSString stringWithFormat:@"%@/%@", wwwFolder, [dirParts componentsJoinedByString:@"/"]];
    } else {
        dirStr = [NSString stringWithFormat:@"%@", [dirParts componentsJoinedByString:@"/"]];
    }
        
    return [mainBundle pathForResource:fname ofType:@"" inDirectory:dirStr];
}

+ (void)showNetworkActivityIndicator:(BOOL)show {
    if(![UIApplication sharedApplication].statusBarHidden) {
        if(show) { [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES]; }
        else { [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO]; }
    }
}

+ (NSString*)getHtmlDirectory { return STATIC_HTML_DIRECTORY; }
+ (NSString*)getApplicationPath { return STATIC_APPLICATION_PATH; }
+ (NSString*)getApplicationTmpPath { return STATIC_APPLICATION_TMP_PATH; }
#ifdef SUPPORT_BXGRNIF
+ (NSString*)getBxgrnifCacheHomePath { return STATIC_BXGRNIF_CACHE_HOME_PATH; }
+ (NSString*)getBxgrnifSavePath { return STATIC_BXGRNIF_SAVE_PATH; }
+ (NSString*)getBxgrnifSharePath { return STATIC_BXGRNIF_SHARE_PATH; }
+ (void)setRunPackageId:(NSString*)pkgId {
    if(STATIC_RUN_PACKAGE_ID_TMP) { [STATIC_RUN_PACKAGE_ID_TMP release]; }
    STATIC_RUN_PACKAGE_ID_TMP = [[NSString alloc] initWithFormat:@"%@", pkgId];
}
+ (NSString*)getRunPackageId { return STATIC_RUN_PACKAGE_ID; }
+ (void)updateRunPackageId {
    if(STATIC_RUN_PACKAGE_ID_TMP) {
        if(STATIC_RUN_PACKAGE_ID) { [STATIC_RUN_PACKAGE_ID release]; }
        STATIC_RUN_PACKAGE_ID = [[NSString alloc] initWithFormat:@"%@", STATIC_RUN_PACKAGE_ID_TMP];
#if DEBUG
        NSLog(@"[N:DEBUG] set current running package id [%@]", STATIC_RUN_PACKAGE_ID);
#endif
        [STATIC_RUN_PACKAGE_ID_TMP release];
        STATIC_RUN_PACKAGE_ID_TMP = nil;
    }
}
#endif

+ (long long)getDiskFreeAmout { return STATIC_DISK_FREE_AMOUT; }
+ (void)setDiskFreeAmount:(long long)amount {
    [STATIC_QUOTA_LOCK lock];
    if(amount < 0) { amount = 0; }

    // disk free space는 100% 정확하지 않기 때문에 특정 조건일때 보정을 한다.
    if(STATIC_QUOTA_REVISION_THRESHOLDS <= STATIC_QUOTA_REVISION_COUNT) {
        [AppDelegate setDiskUsageInformation]; // revision quota
        STATIC_QUOTA_REVISION_COUNT = 0;
    } else {
        if(amount >= STATIC_DISK_LIMIT_AMOUT) {
            [AppDelegate setDiskUsageInformation]; // revision quota
            STATIC_QUOTA_REVISION_COUNT = 0;
        } else {
            STATIC_DISK_FREE_AMOUT = amount;
            [AppDelegate setQuotaAmout:STATIC_DISK_LIMIT_AMOUT-STATIC_DISK_FREE_AMOUT withKind:NO];
            STATIC_QUOTA_REVISION_COUNT++;
        }
    }
    [STATIC_QUOTA_LOCK unlock];
}
+ (long long)getDiskLimitAmount { return STATIC_DISK_LIMIT_AMOUT; }
+ (long long)getDiskUsageAmount { return STATIC_DISK_USAGE_AMOUT; }

// flag가 YES이면 사용 가능한 전체 용량을 적고(__DISK_LIMIT_SPACE 에 기록)
//        NO이면 현재 사용되고 있는 용량을 적는다.(__DISK_USAGE_SPACE 에 기록)
+ (void)setQuotaAmout:(long long)amout withKind:(BOOL)flag {
    int bytesWrite = 0;
    NSData* encData = [[NSString stringWithFormat:@"%lld", amout] dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    NSOutputStream* fos = nil;
    
    if(flag) { fos = [NSOutputStream outputStreamToFileAtPath:STATIC_DISK_LIMIT_AMOUT_PATH append:NO]; }
    else { fos = [NSOutputStream outputStreamToFileAtPath:STATIC_DISK_USAGE_AMOUT_PATH append:NO]; }
    
    @try {
        if(fos) {
            NSUInteger len = [encData length];
            [fos open];
            bytesWrite = [fos write:[encData bytes] maxLength:len];
        }
        if(flag) { STATIC_DISK_LIMIT_AMOUT = amout; }
        else { STATIC_DISK_USAGE_AMOUT = amout; }
    }
    @catch (NSException *exception) {
        NSLog(@"[N:ERROR] write disk setQuotaAmout[%@]", [exception description]);
        if(flag) { STATIC_DISK_LIMIT_AMOUT = -1; }
        else { STATIC_DISK_USAGE_AMOUT = -1; }
    }
    @finally {
        [fos close];
        STATIC_DISK_FREE_AMOUT = STATIC_DISK_LIMIT_AMOUT-STATIC_DISK_USAGE_AMOUT;
        if(STATIC_DISK_FREE_AMOUT < 0) { STATIC_DISK_FREE_AMOUT = 0; }
    }
}

+ (void)setDiskUsageInformation {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    
    // set limit disk space for usage
    // if zero, limit disk space is current free disk space.
    // if -1, application doesn't use disk.
    if(STATIC_QUOTA_DEFINE_SIZE == 0) {
        NSError* err = nil;
        NSDictionary* dict = [fMgr attributesOfFileSystemForPath:STATIC_APPLICATION_PATH error:&err];
        NSNumber* ret = (NSNumber*)[dict objectForKey:NSFileSystemFreeSize];
    
        if(err) { [AppDelegate setQuotaAmout:-1 withKind:YES]; }
        else { [AppDelegate setQuotaAmout:[ret longLongValue] withKind:YES]; }
        
    } else if(STATIC_QUOTA_DEFINE_SIZE < 0) {
        [AppDelegate setQuotaAmout:-1 withKind:YES];
        
    } else {
        NSError* err = nil;
        NSDictionary* dict = [fMgr attributesOfFileSystemForPath:STATIC_APPLICATION_PATH error:&err];
        NSNumber* ret = (NSNumber*)[dict objectForKey:NSFileSystemFreeSize];
        if(err) {
            [AppDelegate setQuotaAmout:-1 withKind:YES];
        } else {
            long long freeSize = [ret longLongValue];
            
            if(STATIC_QUOTA_DEFINE_SIZE <= freeSize) { [AppDelegate setQuotaAmout:STATIC_QUOTA_DEFINE_SIZE withKind:YES]; }
            else { [AppDelegate setQuotaAmout:freeSize withKind:YES]; }
        }
    }
    
    if(STATIC_DISK_LIMIT_AMOUT < 0) {
        [fMgr release];
        STATIC_DISK_FREE_AMOUT = -1;
        STATIC_DISK_USAGE_AMOUT = -1;
    } else {
        NSArray* fileList = [fMgr subpathsAtPath:STATIC_APPLICATION_PATH];
        NSEnumerator* fileEnumerator = [fileList objectEnumerator];
        NSString* filePath = nil;
    
        long long tmp = 0;
        long long total = 0;
    
        while((filePath=[fileEnumerator nextObject])) {
            NSDictionary* tmpDict = [fMgr attributesOfItemAtPath:[NSString stringWithFormat:@"%@/%@", STATIC_APPLICATION_PATH, filePath] error:NULL];
            tmp = [[tmpDict objectForKey:NSFileSize] longLongValue];
            total += tmp;
        }
        [fMgr release];
        [AppDelegate setQuotaAmout:total withKind:NO];
    }
    
#ifdef DEBUG
    if([AppDelegate getDiskFreeAmout] <= 0) {
        NSLog(@"[N:DEBUG] cannot use disk");
    } else {
        NSLog(@"[N:DEBUG] set disk-free-amout=[%lld]", [AppDelegate getDiskFreeAmout]);
    }
#endif
}


#pragma mark -
#pragma mark Support Function
- (NSDictionary*)getDeviceProperties {
    UIDevice* dev = [UIDevice currentDevice];
    NSMutableDictionary* props = [NSMutableDictionary dictionaryWithCapacity:5];
    
    [props setObject:[dev name] forKey:DEV_KEY_NAME];
    [props setObject:[dev systemName] forKey:DEV_KEY_SYS_NAME];
    [props setObject:[dev systemVersion] forKey:DEV_KEY_SYS_VERSION];
    [props setObject:[dev model] forKey:DEV_KEY_MODEL];
    [props setObject:[dev localizedModel] forKey:DEV_KEY_LOCALIZE_MODEL];
    [props setObject:[self getUUID] forKey:DEV_KEY_UUID];
    
    return [NSDictionary dictionaryWithDictionary:props];
}

- (NSString*)getUUID {
    // 단말의 uniqueIdentifer를 바로 가져올 수 있는 방법이 5.0 부터 deprecated 되어
    // 다른 방법으로 uniqueIdentifer를 생성한다. 만일 application을 삭제하고 다시 받을 경우
    // uniqueIdentifer는 변경 된다.
    NSString* uuidFileName = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], FILE_NAME_UUID];
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL bExist = [fMgr fileExistsAtPath:uuidFileName];
    [fMgr release];
    
    if(bExist) {
        m_uuid = [[NSString alloc] initWithContentsOfFile:uuidFileName encoding:NSUTF8StringEncoding error:NULL];
    } else {
        CFUUIDRef u = CFUUIDCreate(NULL);

        CFStringRef uuid = CFUUIDCreateString(NULL, u);
        m_uuid = [[NSString alloc] initWithFormat:@"%@", uuid];
        
        CFRelease(uuid);
        CFRelease(u);

        [m_uuid writeToFile:uuidFileName atomically:YES encoding:NSUTF8StringEncoding error:NULL];
    }
    [uuidFileName release];
    
    return m_uuid;
}

- (id)getClassInstance:(NSString*)className {
    id obj = [m_commandObjects objectForKey:className];
    
    if(!obj) {
        NSDictionary* classConf = [m_config objectForKey:className];
        
        if(classConf) { obj=[[NSClassFromString(className) alloc] initWithWebView:m_webView withConfig:classConf]; }
        else { obj = [[NSClassFromString(className) alloc] initWithWebView:m_webView]; }
        
        [m_commandObjects setObject:obj forKey:className];
        [obj release];
    }

    return obj;
}

- (BOOL)exec:(Invoke*)cmd {
    if(cmd->className==nil || cmd->methodName==nil) return NO;
    
    NSString* methodName = [[NSString alloc] initWithFormat:@"%@:withDict:", cmd->methodName];
    Command* obj = [self getClassInstance:cmd->className];
    
    if([obj respondsToSelector:NSSelectorFromString(methodName)]) {
        [obj performSelector:NSSelectorFromString(methodName) withObject:cmd->argument withObject:cmd->option];
    } else {
        [NSException raise:NSInternalInconsistencyException format:@"[%@] class has not method [%@]",
                cmd->className, methodName];
    }
    [methodName release];
    
    [m_commandPool setFreeElement:cmd];
    [m_webView stringByEvaluatingJavaScriptFromString:@"bluega.ios.Base._queue.ready=true;"];
    
    return YES;
}

- (NSArray*)toNumberForOrientations:(NSArray*)orientations {
    m_rotateOrientation = [[NSMutableArray alloc] init];
    
    if(orientations != nil) {
        NSEnumerator* enumerator = [orientations objectEnumerator];
        NSString* orientationString;
        
        while((orientationString=[enumerator nextObject])) {
            if([orientationString isEqualToString:@"UIInterfaceOrientationPortrait"]) {
				[m_rotateOrientation addObject:[NSNumber numberWithInt:UIInterfaceOrientationPortrait]];
			} else if([orientationString isEqualToString:@"UIInterfaceOrientationPortraitUpsideDown"]) {
				[m_rotateOrientation addObject:[NSNumber numberWithInt:UIInterfaceOrientationPortraitUpsideDown]];
			} else if([orientationString isEqualToString:@"UIInterfaceOrientationLandscapeLeft"]) {
				[m_rotateOrientation addObject:[NSNumber numberWithInt:UIInterfaceOrientationLandscapeLeft]];
			} else if([orientationString isEqualToString:@"UIInterfaceOrientationLandscapeRight"]) {
				[m_rotateOrientation addObject:[NSNumber numberWithInt:UIInterfaceOrientationLandscapeRight]];
			}
        }
    }
    
    if([m_rotateOrientation count] == 0) {
		[m_rotateOrientation addObject:[NSNumber numberWithInt:UIInterfaceOrientationPortrait]];
	}
    
    return m_rotateOrientation;
}

#pragma mark -
#pragma mark Application Launch
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    m_appFirstActivate = YES;
    STATIC_APPLICATION_PATH = [[NSString alloc] initWithFormat:@"%@", 
        [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) componentsJoinedByString:@"/"]];
    m_properties = [[NSDictionary alloc] initWithDictionary:[self getDeviceProperties]];
#ifdef DEBUG
    NSLog(@"[N:DEBUG] application path=[%@]", STATIC_APPLICATION_PATH);
#endif
    m_commandPool = [[CommandPool alloc] init]; // command pool 생성
    
    STATIC_DISK_LIMIT_AMOUT_PATH = [[NSString alloc] initWithFormat:@"%@/%@", STATIC_APPLICATION_PATH, FILE_NAME_DISK_LIMIT_SPACE];
    STATIC_DISK_USAGE_AMOUT_PATH = [[NSString alloc] initWithFormat:@"%@/%@", STATIC_APPLICATION_PATH, FILE_NAME_DISK_USAGE_SPACE];
        
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    self.m_window = [[[UIWindow alloc] initWithFrame:screenBounds] autorelease];
    self.m_window.autoresizesSubviews = YES;
#ifdef DEBUG
    NSLog(@"[N:DEBUG] screenBounds=[%f, %f, %f, %f]", screenBounds.origin.x, screenBounds.origin.y,
        screenBounds.size.width, screenBounds.size.height);
#endif

    NSDictionary* tmp = [[self class] getPropertyList:@"config"];
    m_config = [[NSDictionary alloc] initWithDictionary:tmp];
    
#ifdef DEBUG
    NSLog(@"[N:DEBUG] ghost version=[%@]", [m_config objectForKey:CONFIG_KEY_VERSION]);
#endif    
    
    STATIC_QUOTA_DEFINE_SIZE = [[m_config objectForKey:CONFIG_KEY_DISK_QUOTA] intValue]*1000*1000;
    STATIC_QUOTA_REVISION_THRESHOLDS = [[m_config objectForKey:CONFIG_KEY_DISK_QUOTA_REVISON_THRE] intValue];
    STATIC_HTML_DIRECTORY = [m_config objectForKey:CONFIG_KEY_HTMLDIR];
    
#ifdef DEBUG
    NSLog(@"[N:DEBUG] html directory=[%@]", [AppDelegate getHtmlDirectory]);
#endif
    
    if([[m_config objectForKey:CONFIG_KEY_LOCKSCREEN] boolValue] == YES) {
        [UIApplication sharedApplication].idleTimerDisabled = YES;
#ifdef DEBUG
    NSLog(@"[N:DEBUG] lock screen off");
#endif
    }
    
    // set cache size
    int memoryCacheSize = [[m_config objectForKey:CONFIG_KEY_MEMORY_CACHE_SIZE] intValue] * 1024 * 1024;
    int diskCacheSize = [[m_config objectForKey:CONFIG_KEY_DISK_CACHE_SIZE] intValue] * 1024 * 1024;

#ifdef DEBUG
    NSLog(@"[N:DEBUG] memory cache size for Webview=[%d]", memoryCacheSize);
    NSLog(@"[N:DEBUG] disk cache size for Webview=[%d]", diskCacheSize);
#endif    
    NSURLCache* sharedCache = [[[NSURLCache alloc] initWithMemoryCapacity:memoryCacheSize diskCapacity:diskCacheSize diskPath:@"__BXGCACHE"] autorelease];
    [NSURLCache setSharedURLCache:sharedCache];
    
    self.m_window.backgroundColor = [UIColor blueColor];
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    
    STATIC_APPLICATION_TMP_PATH = [[NSString alloc] initWithFormat:@"%@/tmp", STATIC_APPLICATION_PATH];
    // file system을 사용하기 때문에, temporary directory를 생성.
    // tmp 디렉토리 안에 데이터가 존재한다면 데이터를 삭제 한다.
    // 파일 종료시 logical한 문제가 있어서, 시작시에 삭제를 함.
    if([fMgr fileExistsAtPath:STATIC_APPLICATION_TMP_PATH]==YES) {
        NSError* err = nil;
        if(![fMgr removeItemAtPath:STATIC_APPLICATION_TMP_PATH error:&err]) {
            NSLog(@"[N:ERROR] error removing tmp directory[%@]", [err localizedDescription]);
        }
        if(![fMgr removeItemAtPath:NSTemporaryDirectory() error:&err]) {
            NSLog(@"[N:ERROR] error removing file manager temporary directory[%@]", [err localizedDescription]);
        }
    }
    if([fMgr createDirectoryAtPath:STATIC_APPLICATION_TMP_PATH withIntermediateDirectories:NO attributes:nil error:NULL]==NO) {
        if([fMgr fileExistsAtPath:STATIC_APPLICATION_TMP_PATH]==NO) { NSLog(@"[N:ERROR] The application can't create temporary directory"); }
    }

#ifdef SUPPORT_BXGRNIF
    NSDictionary* bxgrnifConf = [m_config objectForKey:CONFIG_KEY_BXGRNIF];
    
    STATIC_BXGRNIF_CACHE_HOME_PATH = [[NSString alloc] initWithFormat:@"%@/%@", STATIC_APPLICATION_PATH, [bxgrnifConf objectForKey:CONFIG_KEY_BXGRNIF_CACHEHOME]];
    STATIC_BXGRNIF_SAVE_PATH = [[NSString alloc] initWithFormat:@"%@/%@", STATIC_BXGRNIF_CACHE_HOME_PATH, [bxgrnifConf objectForKey:CONFIG_KEY_BXGRNIF_SAVEDIR]];
    STATIC_BXGRNIF_SHARE_PATH = [[NSString alloc] initWithFormat:@"%@/%@/%@", STATIC_BXGRNIF_CACHE_HOME_PATH, 
            [bxgrnifConf objectForKey:CONFIG_KEY_BXGRNIF_SHAREPARENT], [bxgrnifConf objectForKey:CONFIG_KEY_BXGRNIF_SHAREDIR]];
    
    // cacheHome 존재하는지 체크
    BOOL isDir = NO;
    if(![fMgr fileExistsAtPath:STATIC_BXGRNIF_CACHE_HOME_PATH isDirectory:&isDir]) {
        if(![fMgr createDirectoryAtPath:STATIC_BXGRNIF_CACHE_HOME_PATH withIntermediateDirectories:YES attributes:nil error:NULL]) {
            NSLog(@"[N:ERROR] cacheHome [%@] creation failed.", STATIC_BXGRNIF_CACHE_HOME_PATH);
        }
    } else {
        if(!isDir) NSLog(@"[N:ERROR] cacheHome [%@] exist, but it is not directory", STATIC_BXGRNIF_CACHE_HOME_PATH);
    }
    
    // save directory 존재하는지 체크
    isDir = NO;
    if(![fMgr fileExistsAtPath:STATIC_BXGRNIF_SAVE_PATH isDirectory:&isDir]) {
        if(![fMgr createDirectoryAtPath:STATIC_BXGRNIF_SAVE_PATH withIntermediateDirectories:YES attributes:nil error:NULL]) {
            NSLog(@"[N:ERROR] save directory [%@] creation failed.", STATIC_BXGRNIF_SAVE_PATH);
        }
    } else {
        if(!isDir) NSLog(@"[N:ERROR] save directory [%@] exist, but it is not directory", STATIC_BXGRNIF_SAVE_PATH);
    }
    
    // shared directory 존재하는지 체크
    isDir = NO;
    if(![fMgr fileExistsAtPath:STATIC_BXGRNIF_SHARE_PATH isDirectory:&isDir]) {
        if(![fMgr createDirectoryAtPath:STATIC_BXGRNIF_SHARE_PATH withIntermediateDirectories:YES attributes:nil error:NULL]) {
            NSLog(@"[N:ERROR] shared directory [%@] creation failed.", STATIC_BXGRNIF_SHARE_PATH);
        }
    } else {
        if(!isDir) NSLog(@"[N:ERROR] shared directory [%@] exist, but it is not directory", STATIC_BXGRNIF_SHARE_PATH);
    }
#endif

    CGRect webViewBounds = [[UIScreen mainScreen] applicationFrame];
    webViewBounds.origin = screenBounds.origin;
    self.m_webView = [[UIWebView alloc] initWithFrame:webViewBounds];
    self.m_webView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
    
    m_viewController = [[ViewController alloc] init];
    m_viewController.m_supportedOrientation = [self toNumberForOrientations:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"UISupportedInterfaceOrientations"]];
    
    
    self.m_viewController.view.backgroundColor = [UIColor cyanColor];   // for testing
    
    
    self.m_viewController.m_webview = self.m_webView;
    [self.m_viewController.view addSubview:self.m_webView];
    m_webView.delegate = self;
    
    // 만일 로컬 일때 start page가 존재하지 않으면 에러가 난다. 이 에러는 무시하자. 제대로 맞추면 에러 나지 않는다.
    m_loadingKind = [[NSMutableArray alloc] initWithCapacity:10];
    NSURL* startURL = [NSURL URLWithString:[m_config objectForKey:CONFIG_KEY_STARTPAGE]];
    if(![startURL scheme]) {
        startURL = [NSURL fileURLWithPath:[[self class] 
                getPathForResourceFile:[m_config objectForKey:CONFIG_KEY_STARTPAGE] 
                with:[m_config objectForKey:CONFIG_KEY_HTMLDIR]]];
    }
#ifdef DEBUG
    NSLog(@"[N:DEBUG] start page URL=[%@]", startURL);
#endif
    
    [[self class] showNetworkActivityIndicator:YES]; // top status bar 존재 유무에 따라 network indicator가 나온다.
    
    NSURLRequest* request = [NSURLRequest requestWithURL:startURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0];
    [self.m_webView loadRequest:request];
    
    [self.m_window addSubview:m_viewController.view];
    
    // 최초 html 페이지가 뜨기 전에 생기는 텅빈 화면으로 인해 splash 이미지를 잠깐 보여준다.
    UIImage* tmpImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"splash" ofType:@"png"]];
    self.m_imageView = [[UIImageView alloc] initWithImage:tmpImage];
    [tmpImage release];
    self.m_imageView.tag = 1;
    [self.m_window addSubview:m_imageView];

    // activity indicator view(해바라기 모양으로 빙글빙글 돌아가는 indicator를 포함하는 view) 설정
    m_activityView = nil;
    if(![[m_config objectForKey:CONFIG_KEY_ACTIVITY_INDICATOR_STYLE] isEqualToString:CONFIG_VAL_ACTIVITY_INDICATOR_NONE]) {
        UIActivityIndicatorViewStyle topIndicatorStyle = UIActivityIndicatorViewStyleGray;
        if([[m_config objectForKey:CONFIG_KEY_ACTIVITY_INDICATOR_STYLE] isEqualToString:CONFIG_VAL_ACTIVITY_INDICATOR_WHITE]) {
            topIndicatorStyle = UIActivityIndicatorViewStyleWhite;
        } else if([[m_config objectForKey:CONFIG_KEY_ACTIVITY_INDICATOR_STYLE] isEqualToString:CONFIG_VAL_ACTIVITY_INDICATOR_WHITE]) {
            topIndicatorStyle = UIActivityIndicatorViewStyleWhiteLarge;
        } else { ; }
        
        m_activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:topIndicatorStyle];
        m_activityView.center = self.m_window.center;
        
        m_activityView.tag = 2;
        [self.m_window addSubview:m_activityView];
        [m_activityView startAnimating];
    }
    
    [fMgr release];
    [self.m_window makeKeyAndVisible];
        
//    [ViewController setWebviewOrientation:[[UIDevice currentDevice] orientation]];
    return YES;
}

// applicationDidBecomeActive와 반대 개념의 함수
// deactivate 될때는 applicationWillResignActive -> applicationDidEnterBackground 순서로 호출된다.
- (void)applicationWillResignActive:(UIApplication *)application {
#ifdef DEBUG
    NSLog(@"[N:DEBUG] application go to background");
#endif
    NSString* js = 
        @"(function(){"
         "var e = document.createEvent('Events');"
         "e.initEvent('pause');"
         "document.dispatchEvent(e);"
         "if(bx && bx.Event && bx.Event.fire){"
         "bx.Event.fire(document,'bx_activity_state',{name:'bx$Event',value:{action:'onPause'}});"
         "}"
         "})();";
	[m_webView stringByEvaluatingJavaScriptFromString:js];
}
- (void)applicationDidEnterBackground:(UIApplication *)application {}

// application 실행시 및 background에 있던 것이 foreground로 올때, 즉 말그대로 active 될때 호출
// activate 될때는 applicationWillEnterForeground -> applicationDidBecomeActive 순서로 호출된다.
// 원래는 applicationWillEnterForeground 에서 resume을 처리 해 주었으나, 전화 온 이후 '거절'을 선택했을때
// applicationWillEnterForeground 가 호출이 되지 않기 때문에 applicationDidBecomeActive 에서 resume 처리.
- (void)applicationDidBecomeActive:(UIApplication *)application {
#ifdef DEBUG
    NSLog(@"[N:DEBUG] application go to foreground");
#endif
    // application이 사용하는 파일이 많다면 용량 계산 때문에 느려 질수 있을거 같은데...
    [AppDelegate setDiskUsageInformation];
    
    if(m_appFirstActivate) { m_appFirstActivate = NO; } // 게임 launch 시에는 동작하지 않음.
    else {
        NSString* js = 
            @"(function(){"
            "var e = document.createEvent('Events');"
            "e.initEvent('resume');"
            "document.dispatchEvent(e);"
            "if(bx && bx.Event && bx.Event.fire){"
            "bx.Event.fire(document,'bx_activity_state',{name:'bx$Event',value:{action:'onResume'}});"
            "}"
            "})();";
        [m_webView stringByEvaluatingJavaScriptFromString:js];
    }
    
}
- (void)applicationWillEnterForeground:(UIApplication *)application {} // 주의!전화 올때 거절을 선택하면 EnterForeground function이 호출되지 않는다.

// application 이 종료 될때
- (void)applicationWillTerminate:(UIApplication *)application {
    // 정상적으로 종료 되는 경우가 발생할지 의문임.
    // background로 갈때 application을 종료(현재 함수 호출) 하게 할 수 있지만,
    // 이렇게 하면 home button을 눌렀을 경우 application이 종료되는 이슈가 있다....전화 왔을때 application 종료.
    // 또한 iPhone의 하단 proccess bar에서 죽였을 경우는 kill이 되기 때문에
    // applicationWillTerminate 함수가 호출되지 않는다.
    
    //NSFileManager* fMgr = [[NSFileManager alloc] init];
    //NSError* err = nil;
    //
    //if(![fMgr removeItemAtPath:m_applicationTmpPath error:&err]) {
    //    NSLog(@"[N:ERROR] error removing tmp directory[%@]", [err localizedDescription]);
    //}
    //if(![fMgr removeItemAtPath:NSTemporaryDirectory() error:&err]) {
    //    NSLog(@"[N:ERROR] error removing file manager temporary directory[%@]", [err localizedDescription]);
    //}
    //[fMgr release];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    NSLog(@"[N:WARN] occur memory warning. clear URLCache");
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

#pragma mark -
#pragma mark WebView Delegate
// Webview delegate
// Sent after a web view starts loading a frame
- (void)webViewDidStartLoad:(UIWebView *)theWebView {
//    NSLog(@"2. webViewDidStartLoad");
}

// Sent after a web view finishes loading a frame
- (void)webViewDidFinishLoad:(UIWebView *)theWebView {
    if([m_loadingKind count]>0 && [m_loadingKind containsObject:@"1"]) {
        [m_loadingKind removeAllObjects];
        
        NSMutableString* aJS = [[NSMutableString alloc] initWithFormat:@"window.__DEV_INFO=%@;", [m_properties JSONFragment]];
        [aJS appendFormat:@"window.__APP_INFO={\"DocPath\":\"%@\"};", STATIC_APPLICATION_PATH];
        NSBundle* mainBundle = [NSBundle mainBundle];
        
        // 1. WRT base part(base, console)
        NSString* pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"base" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [aJS appendString:pJS];
        [pJS release];
        
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"console" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [aJS appendString:pJS];
        [pJS release];
        
        // evaluator WRT base part
        [theWebView stringByEvaluatingJavaScriptFromString:aJS];
        [aJS release];
        
#ifdef SUPPORT_UTIL
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The util function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"util" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif        
        
#ifdef SUPPORT_FILE
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The file function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"file" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif

#ifdef SUPPORT_SOUND
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The sound function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"sound" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif

#ifdef SUPPORT_NETWORK
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The network function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"network" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif

#ifdef SUPPORT_BGZIP
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The zip function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"zip" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif

#ifdef SUPPORT_BXGRNIF
#ifdef DEBUG
        NSLog(@"[N:DEBUG] [ADDON] The bxgrnif function use");
#endif
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"bxgrnif" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [theWebView stringByEvaluatingJavaScriptFromString:pJS];
        [pJS release];
#endif
        
        // 3. WRT start part
        aJS = [[NSMutableString alloc] initWithFormat:@"bluega.ios.Base.available=true;"];
        pJS = [[NSString stringWithContentsOfFile:[mainBundle pathForResource:@"start" ofType:nil] 
                encoding:NSUTF8StringEncoding error:NULL] retain];
        [aJS appendString:pJS];
        [pJS release];
        if([[m_config objectForKey:CONFIG_KEY_PREVENT_PAGE_SCROLL] boolValue] == YES) {
            [aJS appendString:@"bluega.ios.Start.preventBehavior=function(e){e.preventDefault();};document.addEventListener('touchmove',bluega.ios.Start.preventBehavior,false);"];
        }
        // evaluator WRT start part
        [theWebView stringByEvaluatingJavaScriptFromString:aJS];
        [aJS release];
        
        [self.m_window bringSubviewToFront:m_viewController.view];
        m_webView = theWebView;
        
#ifdef SUPPORT_BXGRNIF
        [AppDelegate updateRunPackageId];
#endif
    }
    
    if(!m_imageView.hidden) {
        m_imageView.hidden = YES;
        [self.m_imageView release];
    }
    if(m_activityView != nil) { [m_activityView stopAnimating]; }
    [[self class] showNetworkActivityIndicator:NO];
}

// Sent if a web view failed to load a frame
- (void)webView:(UIWebView *)theWebView didFailLoadWithError:(NSError *)error {
    NSLog(@"[N:ERROR] Failed to load web-page with error:[%@]", [error localizedDescription]);
}

// Sent before a web view begins loading a frame
- (BOOL)webView:(UIWebView *)theWebView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
//    NSLog(@"1. webView:(UIWebView *)webView shouldStartLoadWithRequest");
    
    NSURL* url = [request URL];
    //NSLog(@"url=[%@]", url);
    
    if([[url scheme] isEqualToString:@"bxg"]) {
        Invoke* objCmd = [m_commandPool getFreeElement];
        [m_commandPool setCommandElementValue:objCmd withURL:url];
        
        // 명령어 실행은 순차적으로 진행된다, 만일 아주 아주 짧은 순간에 급격히 많은 명령어가 
        // 호출이 된다면 thread 방식으로 바꾸는 것을 고려 해 볼만 하다.
        [self exec:objCmd];
        return NO;
        
    } else if([url isFileURL]) {
        // iframe이 포함되어 있을때 web-view에 WRT base javascript를 로딩하지 않기 위해
        if([[[request URL] absoluteString] isEqualToString:[[request mainDocumentURL] absoluteString]])
            [m_loadingKind addObject:[NSString stringWithFormat:@"%d", YES]];
        else
            [m_loadingKind addObject:[NSString stringWithFormat:@"%d", NO]];
        return YES;
    } else if([[url scheme] isEqualToString:@"nwd"]) {
    
        NSLog(@"[N:TODO] scheme open new open webview");
        // 이 부분 run wrt function 하면서 처리하자.
        
        return YES;
    
    } else if([[url scheme] isEqualToString:@"http"] || [[url scheme] isEqualToString:@"https"]) {
        // iframe이 포함되어 있을때 web-view에 WRT base javascript를 로딩하지 않기 위해
        if([[[request URL] absoluteString] isEqualToString:[[request mainDocumentURL] absoluteString]])
            [m_loadingKind addObject:[NSString stringWithFormat:@"%d", YES]];
        else
            [m_loadingKind addObject:[NSString stringWithFormat:@"%d", NO]];
        return YES;
    } else {
        [[UIApplication sharedApplication] openURL:url]; // 새 창을 연다.
        return NO;
    }
    
    return YES;
}

@end
