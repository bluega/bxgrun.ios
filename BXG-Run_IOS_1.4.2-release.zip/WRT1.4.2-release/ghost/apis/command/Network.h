//
//  Network.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 6..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_NETWORK

#import "Command.h"

#define DOWNLOAD_MAX_POOL   3

@class HttpDownloadDelegate;

@interface Network : Command {
    HttpDownloadDelegate* m_downloadPool[DOWNLOAD_MAX_POOL];
}

- (HttpDownloadDelegate*)_getDownloadUnit:(NSString*)downloadURLString;
- (void)getNetworkStatus:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getRemoteHostStatusByName:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getRemoteHostStatusByIp:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)downloadByHttp:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif