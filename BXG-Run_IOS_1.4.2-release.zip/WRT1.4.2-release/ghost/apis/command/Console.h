//
//  Console.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "Command.h"

#define LOG_LEVEL   @"level"

@interface Console : Command

- (void)log:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end
