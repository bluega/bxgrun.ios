//
//  Command.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "Command.h"

@implementation Command

@synthesize m_webView;
@synthesize m_config;

- (Command*)initWithWebView:(UIWebView*)theWebView withConfig:(NSDictionary*)classConfig {
    if((self=[self initWithWebView:theWebView])) {
        [self setM_config:classConfig];
    }
    return self;
}

- (Command*)initWithWebView:(UIWebView*)theWebView {
    if((self=[super init])) { [self setM_webView:theWebView]; }
    return self;
}

- (void)writeJavascript:(NSString*)js { [m_webView stringByEvaluatingJavaScriptFromString:js]; }

- (void)dealloc { [super dealloc]; }

@end
