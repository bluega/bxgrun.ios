//
//  Sound.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 16..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_SOUND

#import "Sound.h"
#import "AppDelegate.h"
#import "AQPlayer.h"


@implementation Sound

#pragma mark -
#pragma mark Alloc Dealloc
- (id)initWithWebView:(UIWebView*)theWebView {
    self = (Sound*)[super initWithWebView:theWebView];
    if(self) {
        m_channelCount = 0;
        for(int i=0 ; i<MAX_STREAM_CHANNEL ; i++) {
            m_streamPool[i] = nil;
        }
    }
    return self;
}

- (id)initWithWebView:(UIWebView*)theWebView withConfig:(NSDictionary*)classConfig {
    self = (Sound*)[super initWithWebView:theWebView withConfig:classConfig];
    if(self) {
        m_channelCount = 0;
        for(int i=0 ; i<MAX_STREAM_CHANNEL ; i++) {
            m_streamPool[i] = nil;
        }
    }
    return self;
}

- (void)dealloc {
    for(int i=0 ; i<MAX_STREAM_CHANNEL ; i++) { delete m_streamPool[i]; }
    [super dealloc];
}

#pragma mark -
#pragma mark WRT Function
- (void)allocStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* filePath = nil;
    if([[args objectAtIndex:3] boolValue]) {
        filePath = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    } else {
        filePath = [AppDelegate getPathForResourceFile:[args objectAtIndex:1] with:[AppDelegate getHtmlDirectory]];
    }
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL bExist = [fMgr fileExistsAtPath:filePath];
    [fMgr release];
    
    NSString* jsStr = nil;
    
    if(!bExist) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'file not found'], false);", [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    if(m_channelCount >= MAX_STREAM_CHANNEL) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'max sound channel'], false);", [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* player = new AQPlayer();
    CFStringRef refFilePath = (CFStringRef)filePath;
    
    player->CreateQueueForFile(refFilePath);
    player->SetJavascriptSoundId([[args objectAtIndex:2] intValue]);
    player->SetLooping(NO);
    
    m_streamPool[m_channelCount++] = player;
    
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
    [self writeJavascript:jsStr];
}

- (void)playStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    for(int i=0 ; i<m_channelCount ; i++) {
        if(m_streamPool[i]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[i];
            break;
        }
    }
    
    if(unit) {
        if(unit->IsRunning()) unit->StopQueue();
        if([args count] >= 3) unit->SetLooping([[args objectAtIndex:2] boolValue]);
        
        OSStatus result = unit->StartQueue(false);
        if(result == noErr) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                [args objectAtIndex:0]];
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'fail play sound clip'], false);", 
                [args objectAtIndex:0]];
        }
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
    
}

- (void)stopStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    int pos = 0;
    for(pos=0 ; pos<m_channelCount ; pos++) {
        if(m_streamPool[pos]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[pos];
            break;
        }
    }
    
    if(unit) {
        if(unit->IsRunning()) {
            OSStatus result = unit->StopQueue();
            
            if(result == noErr) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                    [args objectAtIndex:0]];
            } else {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'fail stop sound clip'], false);", 
                    [args objectAtIndex:0]];
            }
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'The sound clip did not play'], false);", 
                [args objectAtIndex:0]];
        }
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
}

- (void)pauseStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    int pos = 0;
    for(pos=0 ; pos<m_channelCount ; pos++) {
        if(m_streamPool[pos]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[pos];
            break;
        }
    }
    
    if(unit) {
        if(unit->IsRunning()) {
            OSStatus result = unit->PauseQueue();
            
            if(result == noErr) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                    [args objectAtIndex:0]];
            } else {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'fail pause sound clip'], false);", 
                    [args objectAtIndex:0]];
            }
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'The sound clip did not play'], false);", 
                [args objectAtIndex:0]];
        }
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
}

- (void)resumeStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    int pos = 0;
    for(pos=0 ; pos<m_channelCount ; pos++) {
        if(m_streamPool[pos]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[pos];
            break;
        }
    }
    
    if(unit) {
        if(unit->IsRunning()) {
            unit->StartQueue(true);
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'sound clip did not paused'], false);", [args objectAtIndex:0]];
        }
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
}

- (void)deallocStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    int pos = 0;
    for(pos=0 ; pos<m_channelCount ; pos++) {
        if(m_streamPool[pos]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[pos];
            break;
        }
    }
    
    if(unit) {
        if(unit->IsRunning()) unit->StopQueue();
        delete unit;
        m_streamPool[pos] = nil;
        m_channelCount--;
        
        if(pos!=MAX_STREAM_CHANNEL-1) {
            for(int i=pos ; i<MAX_STREAM_CHANNEL ; i++) {
                if(m_streamPool[i+1]==nil) {
                    m_streamPool[i] = nil;
                    break;
                } else {
                    m_streamPool[i] = m_streamPool[i+1];
                }
            }
        }
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
            [args objectAtIndex:0]];
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
}

- (void)setGainStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;

    if(m_channelCount==0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist any sound clip'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    AQPlayer* unit = nil;
    int pos = 0;
    for(pos=0 ; pos<m_channelCount ; pos++) {
        if(m_streamPool[pos]->GetJavascriptSoundId() == [[args objectAtIndex:1] intValue]) {
            unit = m_streamPool[pos];
            break;
        }
    }
    
    if(unit) {
        if(unit->setVolume([[args objectAtIndex:2] floatValue])) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                [args objectAtIndex:0]];
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'setGainStream error in native'], false);", 
                [args objectAtIndex:0]];
        }
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist correct sound clip'], false);", 
            [args objectAtIndex:0]];
    }
    [self writeJavascript:jsStr];
}

@end

#endif