//
//  Util.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 3..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_UTIL) || defined (SUPPORT_BXGRNIF)

#import "Command.h"
#import <AudioToolbox/AudioServices.h>

@interface Util : Command

- (void)vibrate:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)statusBarShow:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getDeviceOrientation:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getMainviewOrientation:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getWebviewOrient:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)setWebviewOrient:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif