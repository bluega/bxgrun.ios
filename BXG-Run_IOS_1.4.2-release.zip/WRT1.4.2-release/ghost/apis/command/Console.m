//
//  Console.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "Console.h"

@implementation Console

- (void)log:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* level = @"INFO";
    if([opts objectForKey:LOG_LEVEL]) level = [opts objectForKey:LOG_LEVEL];
    NSLog(@"[%@] %@", level, [args objectAtIndex:0]);
}

@end
