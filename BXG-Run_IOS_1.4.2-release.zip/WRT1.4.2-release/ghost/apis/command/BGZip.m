//
//  BGZip.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 12..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_BGZIP

#import "BGZip.h"
#import "AppDelegate.h"
#import "ZipFile.h"
#import "ZipException.h"
#import "FileInZipInfo.h"
#import "ZipReadStream.h"
#import "BGFile.h"

@implementation BGZip

#pragma mark -
#pragma mark Alloc Dealloc
- (id)initWithWebView:(UIWebView*)theWebView {
    self = (BGZip*)[super initWithWebView:theWebView];
    if(self) {
        m_bgFile = [[BGFile alloc] init];
    }
    return self;
}

- (void)dealloc {
    [m_bgFile release];
    [super dealloc];
}

#pragma mark -
#pragma mark Support Function
- (void)_bgunzip:(NSArray*)dirInfo {
    NSString* srcZip = [[dirInfo objectAtIndex:0] copy];
    NSString* destDir = [[dirInfo objectAtIndex:1] copy];
    NSString* jsCb = [[NSString alloc] initWithFormat:@"%@", [dirInfo objectAtIndex:2]];

    NSString* jsStr = nil;
    ZipFile* zf = nil;
    NSMutableData* data = nil;
    NSUInteger fileCount;
    NSMutableArray* arrDir = nil;
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    
    @try {
        zf = [[ZipFile alloc] initWithFileName:srcZip mode:ZipFileModeUnzip];
        fileCount = [zf numFilesInZip];
        
        ZipReadStream* zrs = nil;
        data = [[NSMutableData alloc] initWithLength:ZIPFILE_MAX_BUFFSIZE];
        int bytesRead = 0;
        
        NSString* fname = nil;
        NSString* dname = nil;
        NSURL* furl = nil;
        
        [zf goToFirstFileInZip];
        for(int i=0 ; i<fileCount ; i++) {
            [data setLength:ZIPFILE_MAX_BUFFSIZE];
            zrs = [zf readCurrentFileInZip];
            bytesRead = [zrs readDataWithBuffer:data];
            
            [data setLength:bytesRead];
            
            fname = [NSString stringWithFormat:@"%@/%@", destDir, [zrs getFileNameInZip]];
            furl = [NSURL fileURLWithPath:fname];
            arrDir = [[fname componentsSeparatedByString:@"/"] mutableCopy];
            
            [arrDir removeLastObject];
            dname = [arrDir componentsJoinedByString:@"/"];
            
            [fMgr createDirectoryAtPath:dname withIntermediateDirectories:YES attributes:nil error:nil];
            [data writeToURL:furl atomically:NO];
            
            [arrDir release];
            arrDir = nil;
            
            [zrs finishedReading];
            [zf goToNextFileInZip];
        }
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", jsCb];
        [AppDelegate setDiskUsageInformation];  // update quota information
    }
    @catch (NSException *exception) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'exception occur'], false);", jsCb];
    }
    @finally {
        if(zf)      { [zf close]; [zf release]; }
        if(data)    { [data release]; }
        if(arrDir)  { [arrDir release]; }
        [fMgr release];
        [srcZip release];
        [destDir release];
        [jsCb release];
    }
    [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
}

- (void)_writeToJs:(NSString*)jsStr { [self writeJavascript:jsStr]; }

#pragma mark -
#pragma mark WRT Function
- (void)uncompressZip:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* destDir = nil;
    NSString* srcZip = nil;
    if([args count] > 2) {
        srcZip = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
        destDir = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:2]];
    } else {
        srcZip = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
        destDir = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [[args objectAtIndex:1] stringByDeletingPathExtension]];
    }
    
    NSString* jsStr = nil;
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL isDir = NO;
    BOOL isExist = [fMgr fileExistsAtPath:srcZip isDirectory:&isDir];
    
    if(!isExist || isDir) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist zip file'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [srcZip release];
        [destDir release];
        [fMgr release];
        return;
    }
    
    isDir = NO;
    isExist = [fMgr fileExistsAtPath:destDir isDirectory:&isDir];
    if(isExist) {
        if(!isDir) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'exist dest dir name, but it is not directory'], false);", 
                [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
            [srcZip release];
            [destDir release];
            [fMgr release];
            return;
        }
    } else {
        BOOL bRet = [fMgr createDirectoryAtPath:destDir withIntermediateDirectories:YES attributes:nil error:NULL];
        if(!bRet) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot create dest directory'], false);", 
                    [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
            [srcZip release];
            [destDir release];
            [fMgr release];
            return;
        }
    }
    
    // background-run for non-blocking in uncompress job.
    [self performSelectorInBackground:@selector(_bgunzip:) withObject:[NSArray arrayWithObjects:srcZip, destDir, [args objectAtIndex:0], nil]];
    
    [srcZip release];
    [destDir release];
    [fMgr release];
}

@end

#endif