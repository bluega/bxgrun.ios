//
//  File.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 16..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_FILE

#import "Command.h"

@class BGFile;

@interface File : Command {
    BGFile* m_bgFile;
}

- (void)getTotalDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getTotalFreeDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getQuotaTotalDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getQuotaUsageDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getQuotaFreeDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)mkdir:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)rm:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)exist:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)ls:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)writeText:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)readText:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif