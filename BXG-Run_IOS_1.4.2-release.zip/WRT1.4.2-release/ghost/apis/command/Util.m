//
//  Util.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 3..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_UTIL) || defined (SUPPORT_BXGRNIF)

#import "Util.h"
#import "ViewController.h"

@implementation Util

#pragma mark -
#pragma mark WRT Function-Etc
- (void)vibrate:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}

- (void)statusBarShow:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    CGRect statusBar = [[UIApplication sharedApplication] statusBarFrame];
    BOOL isStatusBar = NO;
    switch([ViewController getWebviewOrientation]) {
        case UIInterfaceOrientationPortrait:
        case UIInterfaceOrientationPortraitUpsideDown:
            if(statusBar.size.height > 0) { isStatusBar=YES; }
            break;
        case UIInterfaceOrientationLandscapeLeft:
        case UIInterfaceOrientationLandscapeRight:
        default:
            if(statusBar.size.width > 0) { isStatusBar=YES; }
            break;
    }

    NSString* jsStr = nil;
    if([[args objectAtIndex:1] boolValue]) {
        if(!isStatusBar) {
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_VISIBLE_STATUSBAR object:self 
                userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"NO", NOTI_KEY_STATUSBAR, 
                    [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
        }
    } else {
        if(isStatusBar) {
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_VISIBLE_STATUSBAR object:self 
                userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"YES", NOTI_KEY_STATUSBAR, 
                    [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", 
                [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
        }
    }
}

#pragma mark -
#pragma mark WRT Function-Orientation
- (void)getDeviceOrientation:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
        [args objectAtIndex:0], [[UIDevice currentDevice] orientation]];
    [self writeJavascript:jsStr];
}

- (void)getMainviewOrientation:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
        [args objectAtIndex:0], [ViewController getMainviewOrientation]];
    [self writeJavascript:jsStr];
}

- (void)getWebviewOrient:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
        [args objectAtIndex:0], [ViewController getWebviewOrientation]];
    [self writeJavascript:jsStr];
}

- (void)setWebviewOrient:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 기능 미비로 webview rotate는 다음과 같은 조건을 걸어 둔다.
    // 1. device 의 oreintation 이 portrait가 아니면 지원하지 않는다.
    // 2. status bar가 화면에 보이면 지원하지 않는다.
    
    NSString* jsStr = nil;
    if([ViewController getMainviewOrientation] != UIInterfaceOrientationPortrait) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'device orientation(%d) is not portrait'], false);", 
                [args objectAtIndex:0], [[UIDevice currentDevice] orientation]];
        [self writeJavascript:jsStr];
        return;
    }
    
    int newOrientation = [[args objectAtIndex:1] intValue];
    
    if(newOrientation == [ViewController getWebviewOrientation]) {
#ifdef DEBUG
        NSLog(@"[N:DEBUG] same orientation. don't rotate webview");
#endif
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
                [args objectAtIndex:0], newOrientation];
        [self writeJavascript:jsStr];
        return;
    }

    CGRect statusBar = [[UIApplication sharedApplication] statusBarFrame];
    BOOL isStatusBar = NO;
    
    switch([ViewController getWebviewOrientation]) {
        case UIInterfaceOrientationPortrait:
        case UIInterfaceOrientationPortraitUpsideDown:
            if(statusBar.size.height > 0) { isStatusBar=YES; }
            break;
        case UIInterfaceOrientationLandscapeLeft:
        case UIInterfaceOrientationLandscapeRight:
        default:
            if(statusBar.size.width > 0) { isStatusBar=YES; }
            break;
            break;
    }
    
    if(isStatusBar) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'status-bar is shown. cannot rotate.'], false);", 
                [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }

    switch(newOrientation) {
        case 2: // UIInterfaceOrientationPortraitUpsideDown
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_ROTATE_VIEW object:self 
                    userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"180", NOTI_KEY_ROTATE_VIEW, 
                        [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
            break;
        case 4: // UIInterfaceOrientationLandscapeLeft
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_ROTATE_VIEW object:self 
                    userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"-90", NOTI_KEY_ROTATE_VIEW, 
                        [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
            break;
        case 3: // UIInterfaceOrientationLandscapeRight
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_ROTATE_VIEW object:self 
                    userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"90", NOTI_KEY_ROTATE_VIEW, 
                        [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
            break;
        case 1: // UIInterfaceOrientationPortrait
        default:
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_ID_ROTATE_VIEW object:self 
                    userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"0", NOTI_KEY_ROTATE_VIEW, 
                        [args objectAtIndex:0], NOTI_KEY_CBNAME, nil]];
            break;
    }
}

@end

#endif