//
//  Network.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 6..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_NETWORK

#import "Network.h"
#import "AppDelegate.h"
#import "Reachability.h"
#import "HttpDownloadDelegate.h"

@implementation Network

#pragma mark -
#pragma mark Alloc Dealloc
- (id)initWithWebView:(UIWebView*)theWebView {
    self = (Network*)[super initWithWebView:theWebView];
    if(self) {
        for(int i=0 ; i<DOWNLOAD_MAX_POOL ; i++) {
            HttpDownloadDelegate* unit = [[HttpDownloadDelegate alloc] initWithParent:theWebView withIndex:i];
            m_downloadPool[i] = unit;
        }
    }
    return self;
}

- (void)dealloc {
    for(int i=0 ; i<DOWNLOAD_MAX_POOL ; i++) { [m_downloadPool[i] release]; }
    [super dealloc];
}

#pragma mark -
#pragma mark Support Function
- (HttpDownloadDelegate*)_getDownloadUnit:(NSString*)downloadURLString {
    HttpDownloadDelegate* pRet = nil;

    for(int i=0 ; i<DOWNLOAD_MAX_POOL ; i++) {
        if(![m_downloadPool[i] isActive] && pRet==nil) {
            pRet = m_downloadPool[i];
        } else {
            if([[m_downloadPool[i] getDownloadURLString] isEqualToString:downloadURLString]) {
                return nil;
            }
        }
    }
    return pRet;
}

#pragma mark -
#pragma mark WRT Function
- (void)getNetworkStatus:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 0 : network 사용 off 됨
    // 1 : 3G로 연결됨
    // 2 : WIPI로 연결됨
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
            [args objectAtIndex:0], [[Reachability sharedReachability] internetConnectionStatus]];
    [self writeJavascript:jsStr];
}

- (void)getRemoteHostStatusByName:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 0 : network 사용 off 됨
    // 1 : 3G로 연결됨
    // 2 : WIPI로 연결됨
    [[Reachability sharedReachability] setHostName:[args objectAtIndex:1]];
    [[Reachability sharedReachability] setAddress:nil];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
            [args objectAtIndex:0], [[Reachability sharedReachability] remoteHostStatus]];
    [self writeJavascript:jsStr];
}

- (void)getRemoteHostStatusByIp:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 0 : network 사용 off 됨
    // 1 : 3G로 연결됨
    // 2 : WIPI로 연결됨
    [[Reachability sharedReachability] setAddress:[args objectAtIndex:1]];
    [[Reachability sharedReachability] setHostName:nil];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
            [args objectAtIndex:0], [[Reachability sharedReachability] remoteHostStatus]];
    [self writeJavascript:jsStr];
}

- (void)downloadByHttp:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    if([AppDelegate getDiskFreeAmout] <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot downloadByHttp by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }

    HttpDownloadDelegate* unit = [self _getDownloadUnit:[args objectAtIndex:1]];
    if(!unit) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download-pool is full or already download.'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [unit deActive];
        return;
    }
    
    [unit startDownload:[args objectAtIndex:1] withSavePath:[args objectAtIndex:2] withJsCallback:[args objectAtIndex:0] isBxgrun:BXGRUN_DN_TYPE_None];
}

@end

#endif