//
//  BGZip.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 12..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_BGZIP

#import "Command.h"

@class BGFile;

#define ZIPFILE_MAX_BUFFSIZE    1024*5000   // 5M(sound 때문에 좀 크게 잡았음)
#define NOTI_ID_UNZIP_END   @"Noti_unzipEnd"

@interface BGZip : Command {
    BGFile* m_bgFile;
}

- (void)_bgunzip:(NSArray*)dirInfo;
- (void)_writeToJs:(NSString*)jsStr;
- (void)uncompressZip:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif