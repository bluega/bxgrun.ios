//
//  Bxgrnif.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 6..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_BXGRNIF

#import "Bxgrnif.h"
#import "AppDelegate.h"
#import "Reachability.h"
#import "HttpDownloadDelegate.h"
#import "BGFile.h"

@implementation Bxgrnif

#pragma mark -
#pragma mark Alloc Dealloc
- (id)initWithWebView:(UIWebView*)theWebView withConfig:(NSDictionary*)classConfig {
    self = (Bxgrnif*)[super initWithWebView:theWebView withConfig:classConfig];
    if(self) {
        for(int i=0 ; i<DOWNLOAD_MAX_POOL_IN_BXGRNIF ; i++) {
            HttpDownloadDelegate* unit = [[HttpDownloadDelegate alloc] initWithParent:theWebView withIndex:i];
            m_downloadPool[i] = unit;
        }
        
        m_bgFile = [[BGFile alloc] init];
        m_limitUsagePercent = [[classConfig objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_USAGE_PERCENT] intValue];
        [self _setLimitUsageAmount];
    }
    return self;
}

- (void)dealloc {
    for(int i=0 ; i<DOWNLOAD_MAX_POOL_IN_BXGRNIF ; i++) { [m_downloadPool[i] release]; }
    [m_bgFile release];
    [super dealloc];
}

#pragma mark -
#pragma mark Support Function
- (HttpDownloadDelegate*)_getDownloadUnitInBxgrnif:(NSString*)downloadURLString {
    HttpDownloadDelegate* pRet = nil;

    for(int i=0 ; i<DOWNLOAD_MAX_POOL_IN_BXGRNIF ; i++) {
        if(![m_downloadPool[i] isActive] && pRet==nil) {
            pRet = m_downloadPool[i];
        } else {
            if([[m_downloadPool[i] getDownloadURLString] isEqualToString:downloadURLString]) {
                return nil;
            }
        }
    }
    return pRet;
}

- (void)_setLimitUsageAmount { m_limitUsageAmount = m_limitUsagePercent*[AppDelegate getDiskLimitAmount]/100; }

- (void)_arrangeDiskByQuota:(NSString*)gid withSize:(long long)pkgSize {
    // 삭제 로직을 간단하게 가자.
    // 1. 파라미터로 주어진 gid를 가진 package는 삭제 하지 않는다.(금방 인스톨한 패키지는 삭제 하지 않음을 보장한다)
    // 2. 실행 횟수가 0인 package도 삭제한다.(다운로드 받은 후 한번도 플레이 하지 않음)
    // 3. 결과적으로 실행횟수 역순으로 삭제 하게 된다.
    NSMutableDictionary* pkgByLaunch = nil;
    //NSMutableDictionary* pkgByTimeStamp = nil;
    int i=0;
        
    if(m_limitUsageAmount < [AppDelegate getDiskUsageAmount]+pkgSize) {
        NSFileManager* fMgr = [[NSFileManager alloc] init];
        NSArray* list = [[NSArray alloc] initWithArray:[fMgr contentsOfDirectoryAtPath:[AppDelegate getBxgrnifCacheHomePath] error:NULL]];
        pkgByLaunch = [[NSMutableDictionary alloc] initWithCapacity:[list count]];
        //pkgByTimeStamp = [[NSMutableDictionary alloc] initWithCapacity:[list count]];
    
        // 인스톨 된 패키지 정보를 구하면서 인스톨 실패된 패키지는 삭제 한다.
        int deleteCnt=0;
        for(i=0 ; i<[list count] ; i++) {
            if([m_bgFile isExist:[NSString stringWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i]]] == 1 &&
                    ![[list objectAtIndex:i] isEqualToString:[super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_SHAREPARENT]] &&
                    ![[list objectAtIndex:i] isEqualToString:[super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_SAVEDIR]] &&
                    ![[list objectAtIndex:i] isEqualToString:gid]) {
            
                if([m_bgFile isExist:[NSString stringWithFormat:@"%@/%@/%@", 
                        [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i], GAME_PKG_INSTALL_END]] != 2) {
                    // delete installing incomplete package
                    [m_bgFile remove:[NSString stringWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i]]];
#if DEBUG
            NSLog(@"[N:DEBUG] delete gabage game package. game-id=[%@]", [list objectAtIndex:i]);
#endif
                    deleteCnt++;
                } else {
                    NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:[NSString stringWithFormat:@"%@/%@/%@", 
                            [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i], GAME_PKG_INSTALL_END]];
                    NSString* strCnt = nil;
                    int nCnt = 0;
                    @try {
                        NSData* data = [handle readDataToEndOfFile];
                        strCnt = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
                        nCnt = [strCnt intValue];
                    
                        [pkgByLaunch setValue:[NSNumber numberWithInt:nCnt] forKey:[list objectAtIndex:i]];
                    
                        //NSDictionary* dict = [fMgr attributesOfItemAtPath:[NSString stringWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i]] error:NULL];
                        //long timestamp = (long)[(NSDate*)[dict objectForKey:NSFileCreationDate] timeIntervalSince1970];
                        //[pkgByTimeStamp setValue:[NSNumber numberWithLong:timestamp] forKey:[list objectAtIndex:i]];
                    }
                    @catch (NSException *exception) {
                        NSLog(@"[N:ERROR] file read error[%@]", [exception description]);
                    }
                    @finally {
                        [handle closeFile];
                        if(strCnt) { [strCnt release]; }
                    }
                }
            }
        }
        [list release];
        [fMgr release];
        if(deleteCnt > 0) { [AppDelegate setDiskUsageInformation]; } // 삭제된게 있으면 quota 정보를 업데이트 한다.
    }
    
    if(pkgByLaunch) {
        NSArray* arraybyLaunch = [pkgByLaunch keysSortedByValueUsingComparator:^(id n1, id n2){
            // 실행횟수 작은 것부터 많은것 순으로 정렬
            if([n1 longValue] > [n2 longValue]) return (NSComparisonResult)NSOrderedDescending;
            else if([n1 longValue] < [n2 longValue]) return (NSComparisonResult)NSOrderedAscending;
            return (NSComparisonResult)NSOrderedSame;
        }];

        i = 0;
        while([pkgByLaunch count]>0 && [AppDelegate getDiskUsageAmount]+pkgSize>m_limitUsageAmount) {
            if(![m_bgFile remove:[NSString stringWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [arraybyLaunch objectAtIndex:i]]]) {
                NSLog(@"[N:ERROR] delete package[%@] for cache", [arraybyLaunch objectAtIndex:i]);
                break;
            }
            [pkgByLaunch removeObjectForKey:[arraybyLaunch objectAtIndex:i]];
            [AppDelegate setDiskUsageInformation];
#if DEBUG
            NSLog(@"[N:DEBUG] delete game package. game-id=[%@]", [arraybyLaunch objectAtIndex:i]);
#endif
            i++;
        }
    }
    [pkgByLaunch release];
}

#pragma mark -
#pragma mark WRT Function
- (void)getCacheHomePath:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 절대 패스를 달라고 해서 절대 패스를 돌려줌. 그런데 절대 패스 받아서 사용할데 없을텐데....
    // 추후 상대 패스를 달라고 할 것으로 보이고, 상대 패스 구하는 것은 주석으로 막아 둔다.
    //NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [\"%@\"], false);", 
    //        [args objectAtIndex:0], [super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_CACHEHOME]];
    //[self writeJavascript:jsStr];
    
    // 절대 패스
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [\"%@\"], false);", 
            [args objectAtIndex:0], [AppDelegate getBxgrnifCacheHomePath]];
    [self writeJavascript:jsStr];
}

- (void)isPortalAlive:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    // 0 : network 사용 off 됨
    // 1 : 3G로 연결됨
    // 2 : WIPI로 연결됨
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
            [args objectAtIndex:0], [[Reachability sharedReachability] internetConnectionStatus]];
    [self writeJavascript:jsStr];
}

- (void)saveGameData:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['cannot saveGameData by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    long long usageAmount = 0;
    NSString* savePath = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifSavePath], [args objectAtIndex:1]];
    NSFileManager* fMgr = nil;

    int nExist = [m_bgFile isExist:savePath];
    if(nExist == 2) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['gameid for saving is exist. but it is not directory(%@)'], false);", 
                [args objectAtIndex:0], savePath];
        [self writeJavascript:jsStr];
        [savePath release];
        return;
    } else if(nExist == 0) {
        fMgr = [[NSFileManager alloc] init];
        BOOL bRet = [fMgr createDirectoryAtPath:savePath withIntermediateDirectories:YES attributes:nil error:NULL];
        
        if(!bRet) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['directory(%@) fail for saving'], false);", 
                    [args objectAtIndex:0], savePath];
            [self writeJavascript:jsStr];
            [savePath release];
            [fMgr release];
            return;
        }
        
        NSDictionary* dirDict = [fMgr attributesOfItemAtPath:savePath error:NULL];
        usageAmount += [[dirDict objectForKey:NSFileSize] longLongValue];
    }
    
    if(!fMgr) { fMgr = [[NSFileManager alloc] init]; }
    
    NSString* filePath = [[NSString alloc] initWithFormat:@"%@/%@", savePath, [args objectAtIndex:2]];
    if(![m_bgFile writeTextToFile:filePath withText:[args objectAtIndex:3] append:NO]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['cannot save file(%@)'], false);", 
                    [args objectAtIndex:0], filePath];
        [self writeJavascript:jsStr];
        [filePath release];
        [savePath release];
        return;
    }
    
    NSDictionary* fileDict = [fMgr attributesOfItemAtPath:filePath error:NULL];
    usageAmount += [[fileDict objectForKey:NSFileSize] longLongValue];
    
    [fMgr release];
    [filePath release];
    [savePath release];
    
    [AppDelegate setDiskFreeAmount:freeAmount-usageAmount];
    
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', null, false);", [args objectAtIndex:0]];
    [self writeJavascript:jsStr];
}

- (void)loadGameData:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr;
    NSString* loadPath;
    
    if([args count] <= 2) {
        loadPath = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifSavePath], [args objectAtIndex:1]];
    } else {
        loadPath = [[NSString alloc] initWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifSavePath], [args objectAtIndex:1], [args objectAtIndex:2]];
    }
    
    if([m_bgFile isExist:loadPath] != 2) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['not exist loading file(%@)'], false);", 
                    [args objectAtIndex:0], loadPath];
        [self writeJavascript:jsStr];
        [loadPath release];
        return;
    }
    
    NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:loadPath];
    NSString* retStr = nil;
    @try {
        NSData* data = [handle readDataToEndOfFile];
        retStr = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        NSString* retStr2 = [retStr stringByReplacingOccurrencesOfString:@"'" withString:@"\\'"];
        
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', ['%@'], false);",
            [args objectAtIndex:0], retStr2];
        [self writeJavascript:jsStr];
    }
    @catch (NSException *exception) {
        NSLog(@"[N:ERROR] file read error[%@]", [exception description]);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', ['file(%@) read error'], false);",
            [args objectAtIndex:0], loadPath];
        [self writeJavascript:jsStr];
    }
    @finally {
        [handle closeFile];
        if(retStr) { [retStr release]; }
    }

    [loadPath release];
}

- (void)isResourceStored:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = [[NSString alloc] initWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], [args objectAtIndex:2]];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);",
            [args objectAtIndex:0], [m_bgFile isExist:path]];
    [self writeJavascript:jsStr];
    [path release];
}

- (void)isCached:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = [[NSString alloc] initWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], GAME_PKG_INSTALL_END];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);",
            [args objectAtIndex:0], [m_bgFile isExist:path]];
    [self writeJavascript:jsStr];
    [path release];
}

- (void)saveFile:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot saveFile by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    long long usageAmount = 0;
    NSString* path1 = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:3]];
    
    if([m_bgFile isExist:path1] != 1) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'invalid gameid'], false);",
                [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [path1 release];
        return;
    }
    [path1 release];
    
    NSString* path2 = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:2]];
    
    if([m_bgFile isExist:[path2 stringByDeletingLastPathComponent]] == 2) {
        // 저장할 path가 "a/b/c.txt" 로 들어 올때, "a/b" 가 디렉토리가 아니라 파일로 이미 존재하고 있으면 발생 하는 에러
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'invalid save path. path include file.'], false);",
                [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [path2 release];
        return;
    } else if([m_bgFile isExist:[path2 stringByDeletingLastPathComponent]] == 0) {
        NSFileManager* fMgr = [[NSFileManager alloc] init];
        BOOL bRet = [fMgr createDirectoryAtPath:[path2 stringByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:NULL];
        
        if(!bRet) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot create save path.'], false);",
                [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
            [path2 release];
            [fMgr release];
            return;
        }
        
        NSDictionary* dirDict = [fMgr attributesOfItemAtPath:[path2 stringByDeletingLastPathComponent] error:NULL];
        usageAmount += [[dirDict objectForKey:NSFileSize] longLongValue];
        
        [fMgr release];
    } else {
        // 동일 파일명을 가진 파일이 존재하면 삭제 한다.(규격서상 삭제 하고 다시 다운로드 받아 달라고 함)
        if([m_bgFile isExist:path2]) {
            NSFileManager* fMgr = [[NSFileManager alloc] init];
            NSDictionary* dirDict = [fMgr attributesOfItemAtPath:path2 error:NULL];
            usageAmount -= [[dirDict objectForKey:NSFileSize] longLongValue]; // 최후에는 더 해야 하기 때문에 minus 함.
            [fMgr release];
            
            if(![m_bgFile remove:path2]) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'delete fail(same name file)'], false);",
                    [args objectAtIndex:0]];
                [self writeJavascript:jsStr];
                [path2 release];
                return;
            }
#ifdef DEBUG
            NSLog(@"[N:DEBUG] delete file for saveFile function(same name file)");
#endif
        }
    }
    [path2 release];
    
    [AppDelegate setDiskFreeAmount:freeAmount-usageAmount];
    
    HttpDownloadDelegate* unit = [self _getDownloadUnitInBxgrnif:[args objectAtIndex:1]];
    if(!unit) {
        NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download-pool is full or already download.'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [unit deActive];
        return;
    }
    
    [unit startDownload:[args objectAtIndex:1] withSavePath:[args objectAtIndex:2] withJsCallback:[args objectAtIndex:0] isBxgrun:BXGRUN_DN_TYPE_None];
}

- (void)getGameDescriptor:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    NSString* retStr = nil;
    
    // 인스톨이 완료 되었는 지 부터 체크
    NSString* insPath = [[NSString alloc] initWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], GAME_PKG_INSTALL_END];
    if([m_bgFile isExist:insPath] != 2) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'game installing incompleted'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [insPath release];
        return;
    }
    [insPath release];
    
    NSString* path = [[NSString alloc] initWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], GAME_DESC_FILE_NAME];
    if([m_bgFile isExist:path] != 2) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist game'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [path release];
        return;
    }
    
    NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:path];
    @try {
        NSData* data = [handle readDataToEndOfFile];
        retStr = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, eval(%@)], false);",
            [args objectAtIndex:0], retStr];
    }
    @catch (NSException *exception) {
        NSLog(@"[N:ERROR] file read error[%@]", [exception description]);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot read game descriptor'], false);",
            [args objectAtIndex:0]];
    }
    @finally {
        [handle closeFile];
        if(retStr) { [retStr release]; }
        [path release];
    }
    [self writeJavascript:jsStr];
}

- (void)saveZipFile:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot saveZipFile by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSString* path1 = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:2]];
    
    if([m_bgFile isExist:path1] != 1) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'invalid gameid'], false);",
                [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [path1 release];
        return;
    }
    [path1 release];
    
    // 저장할 디렉토리가 존재하거나 하지 않을때 처리는 다운로드 받은 후 압축 풀때 한다.
    //long long usageAmount = 0;
    //NSString* path2 = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:3]];
    //if(![m_bgFile isExist:path2]) {
    //    NSFileManager* fMgr = [[NSFileManager alloc] init];
    //    BOOL bRet = [fMgr createDirectoryAtPath:path2 withIntermediateDirectories:YES attributes:nil error:NULL];
    //    
    //    if(!bRet) {
    //        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot create saveZip path.'], false);",
    //            [args objectAtIndex:0]];
    //        [self writeJavascript:jsStr];
    //        [path2 release];
    //        [fMgr release];
    //        return;
    //    }
    //    
    //    NSDictionary* dirDict = [fMgr attributesOfItemAtPath:[path2 stringByDeletingLastPathComponent] error:NULL];
    //    usageAmount += [[dirDict objectForKey:NSFileSize] longLongValue];
    //    
    //    [fMgr release];
    //}
    //[path2 release];
    //[AppDelegate setDiskFreeAmount:freeAmount-usageAmount];
    
    HttpDownloadDelegate* unit = [self _getDownloadUnitInBxgrnif:[args objectAtIndex:1]];
    if(!unit) {
        NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download-pool is full or already download.'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [unit deActive];
        return;
    }
    [unit startDownload:[args objectAtIndex:1] 
        withSavePath:[NSString stringWithFormat:@"%@.zip", [args objectAtIndex:3]] 
        withJsCallback:[args objectAtIndex:0] isBxgrun:BXGRUN_DN_TYPE_SaveZipFile];
}

- (void)cachePackage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    
    // 1. 이미 존재하는 package 인지 체크 한다.
    NSString* pkgDirPath = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1]];
    NSString* insFilePath = [[NSString alloc] initWithFormat:@"%@/%@/%@",
                                [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], GAME_PKG_INSTALL_END];
    NSString* descFilePath = [[NSString alloc] initWithFormat:@"%@/%@/%@",
                                [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1], GAME_DESC_FILE_NAME];
    int isPkgDirPath = [m_bgFile isExist:pkgDirPath];
    
    if(isPkgDirPath == 1) {
        if([m_bgFile isExist:insFilePath]==2 && [m_bgFile isExist:descFilePath]==2) {
            NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:descFilePath];
            NSString* descStr = nil;
            @try {
                NSData* data = [handle readDataToEndOfFile];
                descStr = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        
            }
            @catch (NSException *exception) {
                NSLog(@"[N:ERROR] file read error[%@]", [exception description]);
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot read game descriptor for install package'], false);",
                    [args objectAtIndex:0]];
            }
            @finally {
                [handle closeFile];
            }
            
            if(!jsStr) {
                NSMutableDictionary* dict = ((NSMutableDictionary*)[descStr JSONValue]);
                if([[args objectAtIndex:2] isEqualToString:[[dict objectForKey:@"bxgRun_descriptor"] objectForKey:@"version"]]) {
                    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'already exist package'], false);",
                        [args objectAtIndex:0]];
                    [self writeJavascript:jsStr];
                    [pkgDirPath release]; [insFilePath release]; [descFilePath release];
                    [descStr release];
                    return;
                }
                
                // 신규 패키지를 설치하다가 실패 할 수 있으므로 신규 패키지 다운로드 및 임시 설치 이후 
                // 이전에 존재하는 패키지를 삭제 하도록 한다.
                
            } else {
                [self writeJavascript:jsStr];
                [pkgDirPath release]; [insFilePath release]; [descFilePath release];
                [descStr release];
                return;
            }
        } else {
            // package name 과 동일한 디렉토리가 존재하지만, install end file이 존재하지 않는다.(제대로 인스톨 되지 않았다) 삭제 한다.
            if(![m_bgFile remove:pkgDirPath]) {
                // 비 정상적으로 설치된 package 삭제가 실패 했다면
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package name duplicated(1).'], false);", 
                    [args objectAtIndex:0]];
                [self writeJavascript:jsStr];
                [pkgDirPath release]; [insFilePath release]; [descFilePath release];
                return;
            }
        }
    } else if(isPkgDirPath == 2) {
        if(![m_bgFile remove:pkgDirPath]) {
            // package name과 동일한 파일이 존재한다. 파일을 삭제 하려고 했으나 삭제 실패.
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package name duplicated(2).'], false);", 
                [args objectAtIndex:0]];
            [self writeJavascript:jsStr];
            [pkgDirPath release]; [insFilePath release]; [descFilePath release];
            return;
        }
    }
    [pkgDirPath release]; [insFilePath release]; [descFilePath release];

    // 2. 기본 quota 체크
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot cachePackage by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    // 3. quota에 따른 디스크 정리
    [self _arrangeDiskByQuota:[args objectAtIndex:1] withSize:[[args objectAtIndex:4] longLongValue]];
    
    // 4. package 다운로드 & unzip
    HttpDownloadDelegate* unit = [self _getDownloadUnitInBxgrnif:[args objectAtIndex:3]];
    if(!unit) {
        NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download-pool is full or already download.'], false);", 
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        [unit deActive];
        return;
    }
    
    [unit startDownload:[args objectAtIndex:3] 
        withSavePath:[NSString stringWithFormat:@"%@/%@.zip", [super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_CACHEHOME], [args objectAtIndex:1]] 
        withJsCallback:[args objectAtIndex:0] isBxgrun:BXGRUN_DN_TYPE_CachePackage];
}

- (void)cancelCurrentJob:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
#ifdef DEBUG
    NSLog(@"[N:DEBUG] try cancelCurrentJob [start]");
#endif
    for(int i=0 ; i<DOWNLOAD_MAX_POOL_IN_BXGRNIF ; i++) {
        if([m_downloadPool[i] isActive]) {
#ifdef DEBUG
            NSLog(@"[N:DEBUG] do it cancelCurrentJob. url=[%@]", [m_downloadPool[i] getDownloadURLString]);
#endif
            [m_downloadPool[i] stopDownload]; // 모든 다운로드를 종료
        }
    }
#ifdef DEBUG
    NSLog(@"[N:DEBUG] try cancelCurrentJob [end]");
#endif
}

- (void)getCachedGameList:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSArray* list = [[NSArray alloc] initWithArray:[fMgr contentsOfDirectoryAtPath:[AppDelegate getBxgrnifCacheHomePath] error:NULL]];
    [fMgr release];
    
    NSString* retArr[[list count]];
    int arrCount = 0;
    int i=0;
    
    for(i=0 ; i<[list count] ; i++) {
        if(![[list objectAtIndex:i] isEqualToString:[super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_SHAREPARENT]] &&
                ![[list objectAtIndex:i] isEqualToString:[super.m_config objectForKey:BXGRNIF_CONFIG_KEY_BXGRNIF_SAVEDIR]]) {
            if([m_bgFile isExist:[NSString stringWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i], GAME_PKG_INSTALL_END]]==2) {
                NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:[NSString stringWithFormat:@"%@/%@/%@", 
                        [AppDelegate getBxgrnifCacheHomePath], [list objectAtIndex:i], GAME_DESC_FILE_NAME]];
                @try {
                    NSData* data = [handle readDataToEndOfFile];
                    retArr[arrCount] = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
                    arrCount++;
                }
                @catch (NSException *exception) {
                    NSLog(@"[N:ERROR] file read error in getCachedGameList[%@]", [exception description]);
                }
                @finally {
                    [handle closeFile];
                }
            }
        }
    }
    [list release];
    
    NSMutableString* jsStr = [[NSMutableString alloc] initWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, [", [args objectAtIndex:0]];
    for(i=0 ; i<arrCount ; i++) {
        if(i == arrCount-1) { [jsStr appendFormat:@"eval(%@)", retArr[i]]; }
        else { [jsStr appendFormat:@"eval(%@),", retArr[i]]; }
        [retArr[i] release];
    }
    [jsStr appendFormat:@"]], false);"];
    
    [self writeJavascript:jsStr];
    [jsStr release];
}

- (void)isFileExists:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:1]];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);",
            [args objectAtIndex:0], [m_bgFile isExist:path]];
    [self writeJavascript:jsStr];
    [path release];
}

- (void)currentGameId:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    [self writeJavascript:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', ['%@'], false);",
        [args objectAtIndex:0], [AppDelegate getRunPackageId]==nil?@"null":[AppDelegate getRunPackageId]]];
}

- (void)procCommand:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    int argsLength = [args count];
    if(argsLength < 3) {
        [self writeJavascript:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist key/value'], false);",
            [args objectAtIndex:0]]];
        return;
    }
    
    NSString* jsStr = nil;
    NSString* savedData = nil;
    NSString* path = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], PROC_CMD_FILE];
    if([m_bgFile isExist:path] == 2) {
        NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:path];
        @try {
            NSData* data = [handle readDataToEndOfFile];
            savedData = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        }
        @catch (NSException *exception) {
            NSLog(@"[N:ERROR] file read error in procCommand[%@]", [exception description]);
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'reading previous key/pair failed'], false);", [args objectAtIndex:0]];
        }
        @finally {
            [handle closeFile];
        }
    }
    if(jsStr) { [self writeJavascript:jsStr]; return; }
    
    // 멀티가 단일을 포함하고 있기 때문에 구분할 필요가 없는데, 꼭 이렇게 해 달라고 한다.
    if([[args objectAtIndex:1] isEqualToString:PROC_CMD_GET_PREFERENCE]) {
        NSMutableDictionary* savedDict = ((NSMutableDictionary*)[savedData JSONValue]);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, '%@'], false);", [args objectAtIndex:0], 
            [savedDict objectForKey:[args objectAtIndex:2]]?[savedDict objectForKey:[args objectAtIndex:2]]:@""];
    
    } else if([[args objectAtIndex:1] isEqualToString:PROC_CMD_GET_PREFERENCES]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, '%@'], false);", [args objectAtIndex:0], savedData?savedData:@""];
    
    } else if([[args objectAtIndex:1] isEqualToString:PROC_CMD_SET_PREFERENCE] || [[args objectAtIndex:1] isEqualToString:PROC_CMD_SET_PREFERENCES]) {
        NSMutableString* saveString = [[NSMutableString alloc] initWithFormat:@"{"];
        
        for(int i=2 ; i<argsLength ; i+=2) {
            if([[args objectAtIndex:i] length] > 0) {
                if([saveString length] > 1) { [saveString appendString:@","]; }
            
                [saveString appendFormat:@"\"%@\":", [args objectAtIndex:i]];
                
                if(i+1 < argsLength){ [saveString appendFormat:@"\"%@\"", [args objectAtIndex:i+1]]; }
                else                { [saveString appendString:@"\"\""]; }
            }
        }
        [saveString appendString:@"}"];
        
        if([saveString length] > 2) {
            NSMutableDictionary* dict = ((NSMutableDictionary*)[saveString JSONValue]);
            BOOL bWrite = YES;
            
            if(savedData) {
                NSMutableDictionary* savedDict = ((NSMutableDictionary*)[savedData JSONValue]);
                
                if([dict isEqualToDictionary:savedDict]) { bWrite = NO; }
                else {
                    NSEnumerator* enumerator = [savedDict keyEnumerator];
                    id key;
                    while((key=[enumerator nextObject])) {
                        if([dict objectForKey:key] == nil) { [dict setValue:[savedDict objectForKey:key] forKey:key]; }
                    }
                }
            }
            
            if(bWrite) {
                if([m_bgFile writeTextToFile:path withText:[dict JSONFragment] append:NO]) {
                    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
                } else {
                    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'saving key/pair failed'], false);", [args objectAtIndex:0]];
                }
            } else {
                // 저장되어 있는 데이터와 저장할 데이터가 같기 때문에 저장하지 않고, 성공을 리턴
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
            }
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'key/pair does not exist'], false);", [args objectAtIndex:0]];
        }
        [saveString release];
        
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'invalid command'], false);", [args objectAtIndex:0]];
        
    }
    
    if(savedData) { [savedData release]; }
    [path release];
    
    [self writeJavascript:jsStr];
}


#pragma mark -
#pragma mark Hidden Bxgrnif Function
- (void)__loadPage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSURL* startURL = [NSURL URLWithString:[args objectAtIndex:0]];
    
    [AppDelegate showNetworkActivityIndicator:YES]; // top status bar 존재 유무에 따라 network indicator가 나온다.
    [AppDelegate setRunPackageId:[args objectAtIndex:1]]; // page loading이 완료 되면 update할 package id 설정
    
    NSURLRequest* request = [NSURLRequest requestWithURL:startURL cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:20.0];
    [super.m_webView loadRequest:request];
#ifdef DEBUG
    NSLog(@"[N:DEBUG] package start page URL=[%@]", startURL);
#endif
}

// package의 start-page가 valid 한지 invalid 한지 체크 한다.
- (void)__validStartPage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSURL* startURL = [NSURL URLWithString:[args objectAtIndex:1]];
    if(![startURL scheme]) {
        if([m_bgFile isExist:[NSString stringWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:2], [args objectAtIndex:1]]]==2) {
            if([m_bgFile isExist:[NSString stringWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:2], GAME_PKG_INSTALL_END]] != 2) {
                NSLog(@"[N:ERROR] incomplete installed package[%@]", [args objectAtIndex:2]);
                [self writeJavascript:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'incomplete installed package'], false);", [args objectAtIndex:0]]];
                return;
            }
            startURL = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@/%@/%@", [AppDelegate getBxgrnifCacheHomePath], [args objectAtIndex:2], [args objectAtIndex:1]]];
        } else {
            NSLog(@"[N:ERROR] not exist start page[%@] of package", [args objectAtIndex:1]);
            [self writeJavascript:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist start page of package'], false);", [args objectAtIndex:0]]];
            return;
        }
    }
    [self writeJavascript:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, '%@'], false);", [args objectAtIndex:0], startURL]];
}

@end

#endif