//
//  Command.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Command : NSObject

@property (nonatomic, strong) UIWebView* m_webView;
@property (nonatomic, strong) NSDictionary* m_config;

- (Command*)initWithWebView:(UIWebView*)theWebView;
- (Command*)initWithWebView:(UIWebView*)theWebView withConfig:(NSDictionary*)classConfig;
- (void)writeJavascript:(NSString*)js;

@end
