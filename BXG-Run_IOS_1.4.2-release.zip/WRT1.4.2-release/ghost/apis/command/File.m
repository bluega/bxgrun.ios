//
//  File.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 16..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_FILE

#import "File.h"
#import "AppDelegate.h"
#import "BGFile.h"

@implementation File

#pragma mark -
#pragma mark Alloc Dealloc
- (id)initWithWebView:(UIWebView*)theWebView {
    self = (File*)[super initWithWebView:theWebView];
    if(self) {
        m_bgFile = [[BGFile alloc] init];
    }
    return self;
}

- (void)dealloc {
    [m_bgFile release];
    [super dealloc];
}

#pragma mark -
#pragma mark WRT Function
- (void)getTotalDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    NSNumber* ret = [m_bgFile getTotalDiskSpace];

    if(ret == [NSNumber numberWithInt:-1]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%@, 'getting total disk space error in native'], false);", 
            [args objectAtIndex:0], ret];
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%@], false);", 
            [args objectAtIndex:0], ret];
    }
    [self writeJavascript:jsStr];
}

- (void)getTotalFreeDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    NSNumber* ret = [m_bgFile getFreeDiskSpace];
    
    if(ret == [NSNumber numberWithInt:-1]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%@, 'getting total free disk space error in native'], false);", 
            [args objectAtIndex:0], ret];
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%@], false);", 
            [args objectAtIndex:0], ret];
    }
    [self writeJavascript:jsStr];
}

- (void)getQuotaTotalDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%lld], false);", 
            [args objectAtIndex:0], [AppDelegate getDiskLimitAmount]];
    [self writeJavascript:jsStr];
}

- (void)getQuotaUsageDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%lld], false);", 
            [args objectAtIndex:0], [AppDelegate getDiskUsageAmount]];
    [self writeJavascript:jsStr];
}

- (void)getQuotaFreeDiskSpace:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%lld], false);", 
            [args objectAtIndex:0], [AppDelegate getDiskFreeAmout]];
    [self writeJavascript:jsStr];
}

- (void)mkdir:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannnot mkdir by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }

    NSString* path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    
    if([m_bgFile isExist:path] == 1) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'already directory exist'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSError* err = nil;
    BOOL bRet = [fMgr createDirectoryAtPath:path withIntermediateDirectories:[[args objectAtIndex:2] boolValue] attributes:nil error:&err];
    
    if(!bRet) {
        [fMgr release];
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, \"%@\"], false);",
            [args objectAtIndex:0], [err localizedDescription]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSDictionary* tmpDict = [fMgr attributesOfItemAtPath:path error:NULL];
    long long usageAmount = [[tmpDict objectForKey:NSFileSize] longLongValue];
    [fMgr release];
    [AppDelegate setDiskFreeAmount:freeAmount-usageAmount];
    
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
    [self writeJavascript:jsStr];
}

- (void)rm:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount < 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot rm by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSString* path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    
    // directory, file 모두 공용으로 지운다.
    //if(!([self _isExist:path] == 1)) {
    //    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist directory'], false);",
    //        [args objectAtIndex:0]];
    //    [self writeJavascript:jsStr];
    //    return;
    //}
    if([m_bgFile isExist:path] == 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist file in path'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    long long usageAmount = [m_bgFile getDirectorySpace:path];
    
    BOOL bRet = [m_bgFile remove:path];
    if(!bRet) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'remove error in native'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    [AppDelegate setDiskFreeAmount:freeAmount+usageAmount];
    
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", [args objectAtIndex:0]];
    [self writeJavascript:jsStr];
}

- (void)exist:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [%d], false);", 
        [args objectAtIndex:0], [m_bgFile isExist:path]];
    [self writeJavascript:jsStr];
}

- (void)ls:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = nil;
    if([args count] >= 2) { path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]]; }
    else { path = [NSString stringWithFormat:@"%@", [AppDelegate getApplicationPath]]; }
    
    if(!([m_bgFile isExist:path]==1)) {
        NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [null, 'not exist directory'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSMutableString* jsStr2 = [[NSMutableString alloc] initWithFormat:@"(bluega.ios.Base.callback.cb1)('%@',[[", [args objectAtIndex:0]];
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSArray* list = [[NSArray alloc] initWithArray:[fMgr contentsOfDirectoryAtPath:path error:NULL]];
    BOOL isDir = NO;
    
    for(int i=0 ; i<[list count] ; i++) {
        if([args count] >= 2) {
            [fMgr fileExistsAtPath:[NSString stringWithFormat:@"%@/%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1], [list objectAtIndex:i]] isDirectory:&isDir];
            [jsStr2 appendFormat:@"{\"name\":\"%@\",\"fullPath\":\"%@/%@\",", [list objectAtIndex:i], [args objectAtIndex:1], [list objectAtIndex:i]];
        } else {
            [fMgr fileExistsAtPath:[NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [list objectAtIndex:i]] isDirectory:&isDir];
            [jsStr2 appendFormat:@"{\"name\":\"%@\",\"fullPath\":\"%@\",", [list objectAtIndex:i], [list objectAtIndex:i]];
        }
        
        if(isDir) [jsStr2 appendString:@"\"isDirectory\":true,\"isFile\":false}"];
        else [jsStr2 appendString:@"\"isDirectory\":false,\"isFile\":true}"];
        
        if(i < [list count]-1) { [jsStr2 appendString:@","]; }
    }
    [list release];
    [fMgr release];
    
    [jsStr2 appendString:@"]],false);"];
    
    [self writeJavascript:jsStr2];
    [jsStr2 release];
}

- (void)writeText:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* jsStr = nil;
    long long freeAmount = [AppDelegate getDiskFreeAmout];
    if(freeAmount <= 0) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot writeText by quota'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }

    NSString* path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    
    if([m_bgFile isExist:[path stringByDeletingLastPathComponent]] != 1) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'invalid path. not exist parent directory for file'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    if(![m_bgFile writeTextToFile:path withText:[args objectAtIndex:3] append:[[args objectAtIndex:2] boolValue]]) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'file write error'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSDictionary* tmpDict = [fMgr attributesOfItemAtPath:path error:NULL];
    long long usageAmount = [[tmpDict objectForKey:NSFileSize] longLongValue];
    [fMgr release];
    [AppDelegate setDiskFreeAmount:freeAmount-usageAmount];
    
    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);",
            [args objectAtIndex:0]];
    [self writeJavascript:jsStr];
}

- (void)readText:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts {
    NSString* path = [NSString stringWithFormat:@"%@/%@", [AppDelegate getApplicationPath], [args objectAtIndex:1]];
    NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:path];
    NSString* retStr = nil;
    NSString* jsStr = nil;
    
    if(!([m_bgFile isExist:path]==2)) {
        NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not exist file'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
        return;
    }
    
    @try {
        NSData* data = [handle readDataToEndOfFile];
        retStr = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        NSString* retStr2 = [retStr stringByReplacingOccurrencesOfString:@"'" withString:@"\\'"];
        
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, '%@'], false);",
            [args objectAtIndex:0], retStr2];
        [self writeJavascript:jsStr];
    }
    @catch (NSException *exception) {
        NSLog(@"[N:ERROR] file read error[%@]", [exception description]);
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'file read error'], false);",
            [args objectAtIndex:0]];
        [self writeJavascript:jsStr];
    }
    @finally {
        [handle closeFile];
        if(retStr) { [retStr release]; }
    }
}


@end

#endif
