//
//  Sound.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 16..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_SOUND

#import "Command.h"
#import "AQPlayer.h"

#define MAX_STREAM_CHANNEL   16

@interface Sound : Command {
    int m_channelCount;
    AQPlayer* m_streamPool[MAX_STREAM_CHANNEL];
}

- (void)allocStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)playStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)stopStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)pauseStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)resumeStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)deallocStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)setGainStream:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif