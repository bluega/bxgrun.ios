//
//  Bxgrnif.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 6..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#ifdef SUPPORT_BXGRNIF

#import "Command.h"

#define BXGRNIF_CONFIG_KEY_BXGRNIF_CACHEHOME            @"cacheHome"
#define BXGRNIF_CONFIG_KEY_BXGRNIF_SAVEDIR              @"saveDir"
#define BXGRNIF_CONFIG_KEY_BXGRNIF_SHAREPARENT          @"shareParent"
#define BXGRNIF_CONFIG_KEY_BXGRNIF_SHAREDIR             @"shareDir"
#define BXGRNIF_CONFIG_KEY_BXGRNIF_USAGE_PERCENT        @"limitUsagePercent"

#define PROC_CMD_FILE               @".PROC_CMD"
#define PROC_CMD_GET_PREFERENCE     @"GET_PREFERENCE"
#define PROC_CMD_GET_PREFERENCES    @"GET_PREFERENCES"
#define PROC_CMD_SET_PREFERENCE     @"SET_PREFERENCE"
#define PROC_CMD_SET_PREFERENCES    @"SET_PREFERENCES"

#define GAME_DESC_FILE_NAME @"bxggame.json"

// 게임 패키지 다운로드 완료하면 게임 디렉토리에 '.IOS_GMPKG' 이름의 파일 생성.
// 이것으로 게임 설치가 완전하게 완료 되었는지, 아닌지 체크 한다.
// '.IOS_GMPKG' 파일에는 패키지가 몇번 실행 되었는지 실행 횟수 정보가 들어간다.
// 인스톨 된 것은 한번도 실행 되지 않았기 때문에 0 값이 들어간다.
#define GAME_PKG_INSTALL_END    @".IOS_GMPKG"

#define DOWNLOAD_MAX_POOL_IN_BXGRNIF   3

@class HttpDownloadDelegate;
@class BGFile;

@interface Bxgrnif : Command {
    HttpDownloadDelegate* m_downloadPool[DOWNLOAD_MAX_POOL_IN_BXGRNIF];
    BGFile* m_bgFile;
    long long m_limitUsageAmount;
    int m_limitUsagePercent;
}

- (HttpDownloadDelegate*)_getDownloadUnitInBxgrnif:(NSString*)downloadURLString;
- (void)_setLimitUsageAmount;
- (void)_arrangeDiskByQuota:(NSString*)gid withSize:(long long)pkgSize;

- (void)getCacheHomePath:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)isPortalAlive:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)saveGameData:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)loadGameData:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)isResourceStored:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)isCached:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)saveFile:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getGameDescriptor:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)saveZipFile:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)cachePackage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)cancelCurrentJob:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)getCachedGameList:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)isFileExists:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)currentGameId:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)procCommand:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

- (void)__loadPage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;
- (void)__validStartPage:(NSMutableArray*)args withDict:(NSMutableDictionary*)opts;

@end

#endif
