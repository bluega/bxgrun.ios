//
//  CommandPool.m
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import "CommandPool.h"
#import "JSON.h"

@implementation CommandPool

- (CommandPool*)init {
    if((self=[super init])) {
        for(m_i=0 ; m_i<COMMAND_POOL_SIZE ; m_i++) {
            Invoke* element = malloc(sizeof(Invoke));
            element->index      = m_i;
            element->className  = nil;
            element->methodName = nil;
            element->command    = nil;
            element->argument   = nil;
            element->option     = nil;
            
            m_keys[m_i] = YES;
            m_invoke[m_i] = element;
        }
    }
    return self;
}

- (Invoke*)getFreeElement {
    for(m_i=0 ; m_i<COMMAND_POOL_SIZE ; m_i++) {
        if(m_keys[m_i]) {
            m_keys[m_i] = NO;
#ifdef DEBUG_SHOW_COMMAND_SET
            NSLog(@"[N:DEBUG] get free command [%d]", m_i);
#endif
            return m_invoke[m_i];
        }
    }
    return nil;
}

- (void)setFreeElement:(Invoke*)cmd {
#ifdef DEBUG_SHOW_COMMAND_SET
    NSLog(@"[N:DEBUG] set free command [%d]", cmd->index);
#endif
    m_keys[cmd->index] = YES;
}

- (void)setCommandElementValue:(Invoke*)invoke withURL:(NSURL*)url {
    int prefixLength = 0;
    
    // set command, className, methodName
    if(invoke->command==nil) {
        invoke->command = [[NSString alloc] initWithFormat:@"%@", [url host]];
        NSArray* comp = [invoke->command componentsSeparatedByString:@"."];
        if([comp count] >= 2) {
            invoke->className = [[NSString alloc] initWithFormat:@"%@", [comp objectAtIndex:0]];
            invoke->methodName = [[NSString alloc] initWithFormat:@"%@", [comp objectAtIndex:1]];
        } else {
            NSLog(@"[ERROR] command is invalid. command=[%@]", invoke->command);
        }
    } else {
        if(![invoke->command isEqualToString:[url host]]) {
            [invoke->command release];
            [invoke->methodName release];
            [invoke->className release];
            
            invoke->command = [[NSString alloc] initWithFormat:@"%@", [url host]];
            NSArray* comp = [invoke->command componentsSeparatedByString:@"."];
            if([comp count] >= 2) {
                invoke->className = [[NSString alloc] initWithFormat:@"%@", [comp objectAtIndex:0]];
                invoke->methodName = [[NSString alloc] initWithFormat:@"%@", [comp objectAtIndex:1]];
            } else {
                NSLog(@"[ERROR] command is invalid. command=[%@]", invoke->command);
            }
        }
    }
    prefixLength = [[url scheme] length]+[@"://" length]+[invoke->command length]+1;
    
    // set arguments
    NSString* fullURL = [url description];
    int queryLength = [[url query] length];
    int pathLength = [fullURL length] - prefixLength;
    
    if(queryLength > 0) pathLength = pathLength - queryLength -1;
    else if([fullURL hasSuffix:@"/"] && pathLength>0) pathLength -= 1;
    
    NSString* path = @"";
    if(pathLength > 0) path = [fullURL substringWithRange:NSMakeRange(prefixLength, pathLength)];
    
    NSMutableArray* arguments = [NSMutableArray arrayWithArray:[path componentsSeparatedByString:@"/"]];
    int i=0, arguments_count = [arguments count];
    for(i=0 ; i<arguments_count ; i++) {
        [arguments replaceObjectAtIndex:i withObject:[(NSString*)[arguments objectAtIndex:i]
                stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    
    if(invoke->argument==nil) {
        invoke->argument = [[NSMutableArray alloc] initWithArray:arguments];
    } else {
        if(![invoke->argument isEqualToArray:arguments]) {
            [invoke->argument release];
            invoke->argument = [[NSMutableArray alloc] initWithArray:arguments];
        }
    }
    
    // set options
    NSString* strQuery = [[url query] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSMutableDictionary* dict = ((NSMutableDictionary*)[strQuery JSONValue]);
    
    if(invoke->argument==nil) {
        invoke->option = [[NSMutableDictionary alloc] initWithDictionary:dict];
    } else {
        if(![invoke->option isEqualToDictionary:dict]) {
            [invoke->option release];
            invoke->option = [[NSMutableDictionary alloc] initWithDictionary:dict];
        }
    }
}

- (void)dealloc {
    for(int i=0 ; i<COMMAND_POOL_SIZE ; i++) {
        [m_invoke[i]->className release];
        [m_invoke[i]->methodName release];
        [m_invoke[i]->command release];
        [m_invoke[i]->argument release];
        free(m_invoke[i]);
    }
    [super dealloc];
}

@end
