//
//  BGFile.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 18..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_BGZIP) || defined (SUPPORT_BXGRNIF) || defined (SUPPORT_FILE)

#import "BGFile.h"
#import "AppDelegate.h"

@implementation BGFile

#pragma mark -
#pragma mark Alloc Dealloc
- (id)init {
    self = [super init];
    if(self) {
        ;
    }
    return self;
}

- (void)dealloc {
    [super dealloc];
}

- (NSNumber*)getTotalDiskSpace {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSError* err = nil;
    NSDictionary* dict = [fMgr attributesOfFileSystemForPath:[AppDelegate getApplicationPath] error:&err];
    NSNumber* ret = (NSNumber*)[dict objectForKey:NSFileSystemSize];
    [fMgr release];
    
    if(err) { return [NSNumber numberWithInt:-1]; }
    return ret;
}

- (NSNumber*)getFreeDiskSpace {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSError* err = nil;
    NSDictionary* dict = [fMgr attributesOfFileSystemForPath:[AppDelegate getApplicationPath] error:&err];
    NSNumber* ret = (NSNumber*)[dict objectForKey:NSFileSystemFreeSize];
    [fMgr release];
    
    if(err) { return [NSNumber numberWithInt:-1]; }
    return ret;
}

// 디렉토리의 용량을 구한다(디렉토리 내부에 포함되어 있는 모든 파일들의 사이즈 임)
- (unsigned long long)getDirectorySpace:(NSString*)absPath {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    NSArray* fileList = [fMgr subpathsAtPath:absPath];
    NSEnumerator* fileEnumerator = [fileList objectEnumerator];
    NSString* filePath = nil;
    
    unsigned long long tmp = 0;
    unsigned long long total = 0;
    
    while((filePath=[fileEnumerator nextObject])) {
        NSDictionary* tmpDict = [fMgr attributesOfItemAtPath:[NSString stringWithFormat:@"%@/%@", absPath, filePath] error:NULL];
        tmp = [[tmpDict objectForKey:NSFileSize] unsignedLongLongValue];
        total += tmp;
    }
    
    [fMgr release];
    return total;
}

// 디렉토리나 파일 존재 여부 체크.
// 0: 존재하지 않음
// 1: 디렉토리로 존재
// 2: 파일로 존재
- (int)isExist:(NSString*)absPath {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL isDir = NO;
    BOOL isExist = [fMgr fileExistsAtPath:absPath isDirectory:&isDir];
    [fMgr release];
    
    if(isExist) {
        if(isDir) return 1;
        else return 2;
    }
    return 0;
}

- (BOOL)remove:(NSString*)absPath {
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL bRet = [fMgr removeItemAtPath:absPath error:NULL];
    [fMgr release];
    return bRet;
}

- (BOOL)writeTextToFile:(NSString*)absPath withText:(NSString*)text append:(BOOL)isAppend {
    BOOL bRet = YES;
    int bytesWrite = 0;
    NSData* encData = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
    NSOutputStream* fos = [NSOutputStream outputStreamToFileAtPath:absPath append:isAppend];
    
    @try {
        if(fos) {
            NSUInteger len = [encData length];
            [fos open];
            bytesWrite = [fos write:[encData bytes] maxLength:len];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"[N:ERROR] text file write error[%@]", [exception description]);
        bRet = NO;
    }
    @finally {
        [fos close];
    }
    return bRet;
}

@end

#endif