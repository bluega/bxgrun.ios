//
//  HttpDownloadDelegate.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 10..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_NETWORK) || defined (SUPPORT_BXGRNIF)

#import <Foundation/Foundation.h>

#define TIME_OUT                10.0f
#define PROGRESS_PRINT_COUNT    100

#ifdef SUPPORT_BXGRNIF
#define DOWNLOAD_BXGRUN_CACHEPACKAGE    1
#define DOWNLOAD_BXGRUN_SAVEZIPFILE     2
#define ZIPFILE_MAX_BUFFSIZE            1024*5000   // 5M(Sound file 때문에 좀 크게 잡았음)
#define PROGRESS_UNZIP_PRINT_COUNT      100
#define GAME_DESC_FILE_NAME             @"bxggame.json"
#define GAME_PKG_INSTALL_END            @".IOS_GMPKG"
@class BGFile;
#endif

typedef enum {
    BXGRUN_DN_TYPE_None,
    BXGRUN_DN_TYPE_CachePackage,
    BXGRUN_DN_TYPE_SaveZipFile
} DownloadBxgRunType;

@interface HttpDownloadDelegate : NSObject <NSURLConnectionDelegate> {
    int                 m_index;
    BOOL                m_active;
    BOOL                m_finishGettingHeader;
    UIWebView*          m_webview;
    NSURLConnection*    m_connect;
    int                 m_statusCode;
    int                 m_totalSize;
    int                 m_downloadSize;
#ifdef SUPPORT_BXGRNIF
    DownloadBxgRunType  m_isBxgrun;
    BGFile*             m_bgFile;
    BOOL                m_isZipProcess;
    BOOL                m_isZipStop;
#endif
    BOOL                m_isDownloadEnd; // download가 완료되더라도 if(m_connect)가 true 이기 때문에 이것을 넣음.
    int                 m_callProgCount;
    NSDictionary*       m_header;
    NSArray*            m_cookie;
    NSFileManager*      m_fMgr;
}

@property (retain, nonatomic) NSString* m_downloadTmpPath;
@property (retain, nonatomic) NSString* m_downloadPath;
@property (retain, nonatomic) NSString* m_downloadURLString;
@property (retain, nonatomic) NSString* m_jsCallback;

- (void)_downloadBody:(NSURL*)url;
#ifdef SUPPORT_BXGRNIF
- (void)_unzipForBxgrunif:(NSArray*)info;
- (void)_writeToJs:(NSString*)jsStr;
#endif

- (id)initWithParent:(UIWebView*)theWebview withIndex:(int)idx;
- (void)setIndex:(int)idx;
- (int)getIndex;
- (void)deActive;
- (BOOL)isActive;
- (NSString*)getDownloadURLString;
- (void)startDownload:(NSString*)urlString withSavePath:(NSString*)savePath withJsCallback:(NSString*)cb isBxgrun:(DownloadBxgRunType)dnType;
- (void)stopDownload;

@end

#endif