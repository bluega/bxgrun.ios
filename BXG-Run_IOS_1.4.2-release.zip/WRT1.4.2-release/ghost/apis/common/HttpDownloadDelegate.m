//
//  HttpDownloadDelegate.m
//  ghost
//
//  Created by 김 대희 on 12. 4. 10..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_NETWORK) || defined (SUPPORT_BXGRNIF)

#import "HttpDownloadDelegate.h"
#import "AppDelegate.h"
#ifdef SUPPORT_BXGRNIF
#import "ZipFile.h"
#import "ZipException.h"
#import "FileInZipInfo.h"
#import "ZipReadStream.h"
#import "BGFile.h"
#endif

@implementation HttpDownloadDelegate

@synthesize m_downloadPath;
@synthesize m_downloadTmpPath;
@synthesize m_jsCallback;
@synthesize m_downloadURLString;

- (id)initWithParent:(UIWebView*)theWebview withIndex:(int)idx {
    if((self=[super init])) {
        m_webview = theWebview;
        m_index = idx;
        m_active = NO;
        
        m_jsCallback = nil;
        m_downloadTmpPath = nil;
        m_downloadPath = nil;
        
#ifdef SUPPORT_BXGRNIF
        m_isZipProcess = NO;
        m_isBxgrun = BXGRUN_DN_TYPE_None;
        m_bgFile = [[BGFile alloc] init];
#endif
        m_isDownloadEnd = YES;
        m_downloadSize = 0;
        m_connect = nil;
        m_header = nil;
        m_cookie = nil;
        m_finishGettingHeader = NO;
    }
    return self;
}

- (void)setIndex:(int)idx       { m_index = idx; }
- (int)getIndex                 { return m_index; }

- (void)deActive {
    if(m_jsCallback)        { [m_jsCallback release]; m_jsCallback=nil; }
    if(m_downloadTmpPath)   { [m_downloadTmpPath release]; m_downloadTmpPath=nil; }
    if(m_downloadPath)      { [m_downloadPath release]; m_downloadPath=nil; }
    if(m_connect)           { [m_connect release]; m_connect=nil; }
    if(m_header)            { [m_header release]; m_header=nil; }
    if(m_cookie)            { [m_cookie release]; m_cookie=nil; }
    if(m_fMgr)              { [m_fMgr release]; m_fMgr=nil; }
    if(m_downloadURLString) { [m_downloadURLString release]; m_downloadURLString=nil; }
    
#ifdef SUPPORT_BXGRNIF  
    m_isZipProcess = NO;
    m_isZipStop = NO;
#endif
    m_isDownloadEnd = YES;
    m_active = NO;
}
- (BOOL)isActive                { return m_active; }

- (NSString*)getDownloadURLString { return m_downloadURLString; }

#ifdef SUPPORT_BXGRNIF
- (void)_unzipForBxgrunif:(NSArray*)info {
    NSString* zipFileName = [[info objectAtIndex:0] copy];
    NSString* jsCb = [[info objectAtIndex:1] copy];
    NSString* destDir = [[NSString alloc] initWithFormat:@"%@_tmp", [zipFileName stringByDeletingPathExtension]];
    NSString* jsStr = nil;
    
    if([m_bgFile isExist:destDir]) {
        if(![m_bgFile remove:destDir]) {
            // 동일 이름의 임시 디렉토리나 파일이 있는데 삭제 불가능(압축 풀기 임시 디렉토리 생성 실패-이미 존재하는 동일명 디렉토리 삭제 실패)
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(1)'], false);", jsCb];
            [zipFileName release];
            [jsCb release];
            [destDir release];
            [self deActive];
            [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
            return;
        }
    }
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL bRet = [fMgr createDirectoryAtPath:destDir withIntermediateDirectories:YES attributes:nil error:NULL];
    if(!bRet) {
        // 압축을 풀기 위한 임시 디렉토리 생성 실패
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(2)'], false);", jsCb];
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [fMgr release];
        [self deActive];
        [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
        return;
    }
    
    ZipFile* zf = nil;
    NSUInteger fileCount;
    NSMutableData* data = nil;
    NSMutableArray* arrDir = nil;
    
    @try {
        zf = [[ZipFile alloc] initWithFileName:zipFileName mode:ZipFileModeUnzip];
        fileCount = [zf numFilesInZip];
        
        ZipReadStream* zrs = nil;
        data = [[NSMutableData alloc] initWithLength:ZIPFILE_MAX_BUFFSIZE];
        int bytesRead = 0;
        
        NSString* fname = nil;
        NSString* dname = nil;
        NSURL* furl = nil;
        
        [zf goToFirstFileInZip];
        for(int i=0 ; i<fileCount ; i++) {
            if(m_isZipStop) {
                [self performSelectorOnMainThread:@selector(_writeToJs:) 
                        withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'User canceled'], false);", jsCb] 
                        waitUntilDone:YES];
                
                // 압축 풀던 잔해 정리
                [m_bgFile remove:zipFileName];
                [m_bgFile remove:destDir];
                        
                [zipFileName release];
                [jsCb release];
                [destDir release];
                [fMgr release];
                
                [self deActive];
                return;
            }
        
            [data setLength:ZIPFILE_MAX_BUFFSIZE];
            zrs = [zf readCurrentFileInZip];
            
            bytesRead = [zrs readDataWithBuffer:data];
            
            [data setLength:bytesRead];
            
            fname = [NSString stringWithFormat:@"%@/%@", destDir, [zrs getFileNameInZip]];
            furl = [NSURL fileURLWithPath:fname];
            arrDir = [[fname componentsSeparatedByString:@"/"] mutableCopy];
            
            [arrDir removeLastObject];
            dname = [arrDir componentsJoinedByString:@"/"];
            
            [fMgr createDirectoryAtPath:dname withIntermediateDirectories:YES attributes:nil error:nil];
            [data writeToURL:furl atomically:NO];
            
            [arrDir release];
            arrDir = nil;
            
            [zrs finishedReading];
            [zf goToNextFileInZip];
            
            if(i%PROGRESS_UNZIP_PRINT_COUNT == 0) {
                [self performSelectorOnMainThread:@selector(_writeToJs:) 
                    withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [201, %d, %d], true);", jsCb, i+1, fileCount] 
                    waitUntilDone:YES];
            }
        }
        [self performSelectorOnMainThread:@selector(_writeToJs:) 
                withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [202, %d, %d], true);", jsCb, fileCount, fileCount] 
                waitUntilDone:YES];
    }
    @catch (NSException *exception) {
        // 압축 풀때 에러 발생
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(3)'], false);", jsCb];
    }
    @finally {
        if(zf)      { [zf close]; [zf release]; }
        if(data)    { [data release]; }
        if(arrDir)  { [arrDir release]; }
    }
    
    if(jsStr) {
        [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [fMgr release];
        [self deActive];
        return;
    }
    
    NSString* pkgDirName = [[NSString alloc] initWithFormat:@"%@", [zipFileName stringByDeletingPathExtension]];
    
    if([m_bgFile isExist:pkgDirName]) {
        if(![m_bgFile remove:pkgDirName]) {
            // 동일한 이름의 package directory 삭제 실패
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(4)'], false);", jsCb];
            [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
            [zipFileName release];
            [jsCb release];
            [destDir release];
            [pkgDirName release];
            [fMgr release];
            [self deActive];
            return;
        }
    }
    
    BOOL bMove = [fMgr moveItemAtPath:destDir toPath:pkgDirName error:NULL];
    [fMgr release];
    if(!bMove) {
        // 압축을 푼 패키지 디렉토리를 원래 이름으로 이동 실패
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(5)'], false);", jsCb];
        [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [pkgDirName release];
        [self deActive];
        return;
    }
    
    [m_bgFile remove:zipFileName]; // zip 삭제. 에러 처리 하지 않음. 에러 처리 필요 없음.
    
    // saveZipFile 에서 호출 했을 경우에는 package check 및 package description을 읽어 올 필요 없다.
    if(m_isBxgrun == BXGRUN_DN_TYPE_SaveZipFile) {
        [AppDelegate setDiskUsageInformation];  // update quota information
        
        [self performSelectorOnMainThread:@selector(_writeToJs:) 
            withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", jsCb] 
            waitUntilDone:YES];
        
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [pkgDirName release];
        [self deActive];
        return;
    }
    
    // 게임 정보 읽어 와야 한다.
    NSString* descFile = [[NSString alloc] initWithFormat:@"%@/%@", pkgDirName, GAME_DESC_FILE_NAME];
    if([m_bgFile isExist:descFile]!=2) {
        // 다운로드 받은 package에 description 파일이 없음.
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(6)'], false);", jsCb];
        [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [pkgDirName release];
        [descFile release];
        [self deActive];
        return;
    }
    
    NSFileHandle* handle = [NSFileHandle fileHandleForReadingAtPath:descFile];
    NSString* descStr = nil;
    @try {
        NSData* data = [handle readDataToEndOfFile];
        descStr = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
    }
    @catch (NSException *exception) {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(7)'], false);", jsCb];
    }
    @finally {
        [handle closeFile];
    }
    
    if(jsStr) {
        [self performSelectorOnMainThread:@selector(_writeToJs:) withObject:jsStr waitUntilDone:YES];
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [pkgDirName release];
        [descStr release];
        [descFile release];
        [self deActive];
        return;
    }
    
    // 인스톨 완료 파일 생성
    NSString* insComplete = [[NSString alloc] initWithFormat:@"%@/%@", pkgDirName, GAME_PKG_INSTALL_END];
    if(![m_bgFile writeTextToFile:insComplete withText:@"0" append:NO]) {
        [self performSelectorOnMainThread:@selector(_writeToJs:) 
            withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'package cannont unzip(7)'], false);", jsCb] 
            waitUntilDone:YES];
            
        [zipFileName release];
        [jsCb release];
        [destDir release];
        [pkgDirName release];
        [descStr release];
        [descFile release];
        [insComplete release];
        [self deActive];
        return;
    }
     
    NSString* entryURL = nil;
    BOOL landscape = NO;
    if(!jsStr) {
        NSMutableDictionary* dict = ((NSMutableDictionary*)[descStr JSONValue]);
        entryURL = [[NSString alloc] initWithFormat:@"%@", [[dict objectForKey:@"bxgRun_descriptor"] objectForKey:@"entryURL"]];
        landscape = [[[dict objectForKey:@"bxgRun_descriptor"] objectForKey:@"landscape"] boolValue];
    }
    
    [self performSelectorOnMainThread:@selector(_writeToJs:) 
            withObject:[NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true, '%@', %@], false);", 
                jsCb, entryURL, landscape?@"true":@"false"] 
            waitUntilDone:YES];
    
    [zipFileName release];
    [jsCb release];
    [destDir release];
    [pkgDirName release];
    [descStr release];
    [descFile release];
    [entryURL release];
    [insComplete release];
    [self deActive];
    
    [AppDelegate setDiskUsageInformation];  // update quota information
}
- (void)_writeToJs:(NSString*)jsStr { [m_webview stringByEvaluatingJavaScriptFromString:jsStr]; }
#endif

- (void)_downloadBody:(NSURL*)url {
    m_fMgr = [[NSFileManager alloc] init];

    UInt32 size = [[m_fMgr attributesOfItemAtPath:m_downloadTmpPath error:NULL] fileSize];
    
    // 다운로드 받을 위치에 혹시 동일 이름의 파일이 있는지 체크(사이즈만 체크 해서 파일 비교된다. 다른 파일이라도 사이즈가 동일하면 동일 파일로 취급)
    BOOL isDir = NO;
    BOOL isExist = [m_fMgr fileExistsAtPath:m_downloadPath isDirectory:&isDir];
    
    if(isExist) {
        NSString* jsStr = nil;
        if(isDir) {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download fail. same name directory exist'], false);", 
                m_jsCallback];
            [self deActive];
        } else {
            UInt32 existSize = [[m_fMgr attributesOfItemAtPath:m_downloadPath error:NULL] fileSize];
            if(existSize == m_totalSize) {
#ifdef SUPPORT_BXGRNIF
                if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
                    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [4, %d, %d], true);", m_jsCallback, m_totalSize, m_totalSize];
                    [self performSelectorInBackground:@selector(_unzipForBxgrunif:) withObject:[NSArray arrayWithObjects:m_downloadPath, m_jsCallback, nil]];
                } else {
#endif
                    jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", m_jsCallback];
                    [self deActive];
#ifdef SUPPORT_BXGRNIF
                }
#endif
            } else {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download fail. same name file exist'], false);", 
                    m_jsCallback];
                [self deActive];
            }
        }
        [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        return;
    }
    
    // 정확하게 파일을 비교하지는 않고, 단순 사이즈로 파일 비교 한다.
    if(size == m_totalSize) {
        BOOL bMove = [m_fMgr moveItemAtPath:m_downloadTmpPath toPath:m_downloadPath error:NULL];
        NSString* jsStr = nil;
        if(bMove) {
#ifdef SUPPORT_BXGRNIF
            if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [4, %d, %d], true);", m_jsCallback, m_totalSize, m_totalSize];
                [self performSelectorInBackground:@selector(_unzipForBxgrunif:) withObject:[NSArray arrayWithObjects:m_downloadPath, m_jsCallback, nil]];
            } else {
#endif
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", m_jsCallback];
                [AppDelegate setDiskFreeAmount:[AppDelegate getDiskFreeAmout]-m_totalSize];
                [self deActive];
#ifdef SUPPORT_BXGRNIF
            }
#endif
        } else {
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download success, but cannot move correct location.'], false);", 
                m_jsCallback];
            [self deActive];
        }
        [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        return;
    } else if(size > m_totalSize) {
        // 이러면 다른 파일임.
        BOOL bRet = [m_fMgr removeItemAtPath:m_downloadTmpPath error:NULL];
        if(!bRet) {
            NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot delete same name file in tmp directory'], false);", 
                    m_jsCallback];
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            [self deActive];
            return;
        }
        size = 0;
    }
    
    m_downloadSize = 0;
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:url 
            cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:TIME_OUT];
    if(size > 0) {
        [request addValue:[NSString stringWithFormat:@"bytes=%lu-", size] forHTTPHeaderField:@"Range"];
        m_downloadSize = size;
    }
    
    m_finishGettingHeader = YES;
    m_connect = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
}

- (void)startDownload:(NSString*)urlString withSavePath:(NSString*)savePath withJsCallback:(NSString*)cb isBxgrun:(DownloadBxgRunType)dnType {
    m_active = YES;
#ifdef SUPPORT_BXGRNIF  
    m_isZipProcess = NO;
    m_isZipStop = NO;
#endif
    
    m_downloadTmpPath = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationTmpPath], [savePath lastPathComponent]];
    m_downloadPath = [[NSString alloc] initWithFormat:@"%@/%@", [AppDelegate getApplicationPath], savePath];
    m_downloadURLString = [[NSString alloc] initWithFormat:@"%@", urlString];
#ifdef SUPPORT_BXGRNIF
    m_isBxgrun = dnType;
#endif
    
    NSFileManager* fMgr = [[NSFileManager alloc] init];
    BOOL isDir = NO;
    BOOL isExist = [fMgr fileExistsAtPath:m_downloadTmpPath isDirectory:&isDir];
    
    if(isExist) {
        if(isDir) {
            BOOL bRet = [fMgr removeItemAtPath:m_downloadTmpPath error:NULL];
            if(!bRet) {
                NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'cannot delete same name directory in tmp directory'], false);", 
                        cb];
                [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
                [fMgr release];
                [self deActive];
                return;
            }
        }
    }
    [fMgr release];
    
    m_jsCallback = [[NSString alloc] initWithFormat:@"%@", cb];
    
    NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlString] 
            cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:TIME_OUT];
    
    // 처음에는 header만 받는다.
    m_finishGettingHeader = NO;
    m_totalSize = 0;
    m_callProgCount = 0;
    
    // 연결 전에 취소 할수 있기 때문에..
    if(m_active) {
        m_isDownloadEnd = NO;
        m_connect = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES];
    } else {
        [self deActive];
    }
    
    // loop 안 돌려도 다운로드 되네??? 왜 그렇지???
    //m_finish = NO;
    //while(!m_finish) {
    //    if(![[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]]) {
    //        break;
    //    }
    //}
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    m_statusCode = [(NSHTTPURLResponse*)response statusCode];
    
    m_header = [[NSDictionary alloc] initWithDictionary:[(NSHTTPURLResponse*)response allHeaderFields]];
    if(m_header) {
        m_cookie = [[NSArray alloc] initWithArray:[NSHTTPCookie cookiesWithResponseHeaderFields:m_header forURL:[response URL]]];
    }
    
    if(!m_finishGettingHeader) {
        [m_connect cancel];
        [m_connect release];
        m_connect = nil;
        
#ifdef SUPPORT_BXGRNIF
        if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
            // 다운로드 받을 파일이 zip 파일인지 아닌지 체크 한다.
            // zip 파일은 Content-Type 이 "application/zip" 넘어오는데 혹시 모르니, 
            // 정확한 단어 체크가 아닌 패턴(%zip%) 으로 체크 한다.
            NSRange range = [[m_header objectForKey:@"Content-Type"] rangeOfString:@"zip"];
            if(range.length <= 0) {
                // Content-type에 zip 이라는 단어가 없다.
#ifdef DEBUG
                NSLog(@"[N:WARN] Content-Type of download-file=[%@] is not zip", [m_header objectForKey:@"Content-Type"]);
#endif
                NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download file is not zip file'], false);", 
                        m_jsCallback];
                [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
                [self deActive];
                return;
            }
        }
#endif
    
        m_totalSize = [[m_header objectForKey:@"Content-Length"] intValue];
        if(m_header) { [m_header release]; m_header=nil; }
        if(m_cookie) { [m_cookie release]; m_cookie=nil; }
    
        if(m_statusCode >= 300) {
            NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download fail. url fault. http-code:%d'], false);", 
                        m_jsCallback, m_statusCode];
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            [self deActive];
            return;
        }
        
        if(m_totalSize > [AppDelegate getDiskFreeAmout]) {
            NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'not enough disk space'], false);", 
                        m_jsCallback, m_statusCode];
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            [self deActive];
            return;
        }
        
        [self _downloadBody:[response URL]];
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    m_downloadSize += [data length];
    if([m_fMgr fileExistsAtPath:m_downloadTmpPath]) {
        NSFileHandle* fHandle = [NSFileHandle fileHandleForWritingAtPath:m_downloadTmpPath];
        [fHandle seekToEndOfFile];
        [fHandle writeData:data];
        [fHandle closeFile];
        
        m_callProgCount = (m_callProgCount+1)%PROGRESS_PRINT_COUNT;
        if(m_callProgCount==0) {
            NSString* jsStr = nil;
#ifdef SUPPORT_BXGRNIF
            if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [3, %d, %d], true);", 
                        m_jsCallback, m_downloadSize, m_totalSize];
            } else {
#endif
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [%d, %d], true);", 
                        m_jsCallback, m_downloadSize, m_totalSize];
#ifdef SUPPORT_BXGRNIF
            }
#endif
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
        }
    } else {
        BOOL bWrite = [data writeToFile:m_downloadTmpPath atomically:YES];
        if(bWrite) {
            // seed file 생성. 최초 저장.
            NSString* jsStr = nil;
#ifdef SUPPORT_BXGRNIF
            if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [3, %d, %d], true);", 
                        m_jsCallback, m_downloadSize, m_totalSize];
            } else {
#endif
                jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [%d, %d], true);", 
                        m_jsCallback, m_downloadSize, m_totalSize];
#ifdef SUPPORT_BXGRNIF
            }
#endif
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            m_callProgCount++;
        } else {
            [m_connect cancel];
            [self deActive];
        
            NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download fail. cannot create seed file'], false);", 
                        m_jsCallback];
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            return;
        }
    }
}

- (void)stopDownload {
    if(m_active) {
        if(m_connect && !m_isDownloadEnd) { // 다운로드 들어가기 전에는 취소가 안 먹힌다.
            [m_connect cancel];
            NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'User canceled'], false);", m_jsCallback];
            [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
            [self deActive];
        }
#ifdef SUPPORT_BXGRNIF
        if(m_isZipProcess) { m_isZipStop = YES; }
#endif        
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError*)error {
    [self deActive];
    NSString* jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download fail by calling error callback in native'], false);", 
            m_jsCallback];
    [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
}

- (void)connectionDidFinishLoading:(NSURLConnection*)connection {
    m_isDownloadEnd = YES;
    BOOL bMove = [m_fMgr moveItemAtPath:m_downloadTmpPath toPath:m_downloadPath error:NULL];
    NSString* jsStr = nil;
    if(bMove) {
#ifdef SUPPORT_BXGRNIF
        if(m_isBxgrun==BXGRUN_DN_TYPE_CachePackage || m_isBxgrun==BXGRUN_DN_TYPE_SaveZipFile) {
            m_isZipProcess = YES;
            m_isZipStop = NO;
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb2)('%@', [4, %d, %d], true);", m_jsCallback, m_totalSize, m_totalSize];
            [self performSelectorInBackground:@selector(_unzipForBxgrunif:) withObject:[NSArray arrayWithObjects:m_downloadPath, m_jsCallback, nil]];
        } else {
#endif
            jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [true], false);", m_jsCallback];
            [AppDelegate setDiskFreeAmount:[AppDelegate getDiskFreeAmout]-m_totalSize];
            [self deActive];
#ifdef SUPPORT_BXGRNIF
        }
#endif
    } else {
        jsStr = [NSString stringWithFormat:@"(bluega.ios.Base.callback.cb1)('%@', [false, 'download success, but cannot move correct location.'], false);", 
            m_jsCallback];
        [self deActive];
    }
    [m_webview stringByEvaluatingJavaScriptFromString:jsStr];
}

- (void)dealloc {
    if(m_downloadPath)      { [m_downloadPath release]; }
    if(m_downloadTmpPath)   { [m_downloadTmpPath release]; }
    if(m_jsCallback)        { [m_jsCallback release]; }
    if(m_connect)           { [m_connect release]; }
    if(m_header)            { [m_header release]; }
    if(m_cookie)            { [m_cookie release]; }
    if(m_fMgr)              { [m_fMgr release]; }
    if(m_downloadURLString) { [m_downloadURLString release]; }
    
    [super dealloc];
}

@end

#endif