//
//  BGFile.h
//  ghost
//
//  Created by 김 대희 on 12. 4. 18..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#if defined (SUPPORT_BGZIP) || defined (SUPPORT_BXGRNIF) || defined (SUPPORT_FILE)

#import <Foundation/Foundation.h>

@interface BGFile : NSObject

- (NSNumber*)getTotalDiskSpace;
- (NSNumber*)getFreeDiskSpace;
- (unsigned long long)getDirectorySpace:(NSString*)absPath;
- (int)isExist:(NSString*)absPath;
- (BOOL)remove:(NSString*)absPath;
- (BOOL)writeTextToFile:(NSString*)absPath withText:(NSString*)text append:(BOOL)isAppend;

@end

#endif