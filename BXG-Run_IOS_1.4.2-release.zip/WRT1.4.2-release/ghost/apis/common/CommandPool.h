//
//  CommandPool.h
//  ghost
//
//  Created by 김 대희 on 12. 3. 13..
//  Copyright (c) 2012년 블루가. All rights reserved.
//

#import <Foundation/Foundation.h>

// native call을 하기 위한 동시 지원 명령어 갯수
// 단순 테스트 결과 거의 하나를 사용하기 때문에 넉넉하게 몇개만 잡아주자
#define COMMAND_POOL_SIZE   5

// command get, set 로그를 보려면 아래 define 주석을 풀어준다.
//#define DEBUG_SHOW_COMMAND_SET

typedef struct _Invoke {
    int index;
    NSString* className;
    NSString* methodName;
    NSString* command;
    NSMutableArray* argument;
    NSMutableDictionary* option;
} Invoke;

@interface CommandPool : NSObject {
    int m_i;
    BOOL m_keys[COMMAND_POOL_SIZE];
    Invoke* m_invoke[COMMAND_POOL_SIZE];
}

- (Invoke*)getFreeElement;
- (void)setFreeElement:(Invoke*)cmd;
- (void)setCommandElementValue:(Invoke*)invoke withURL:(NSURL*)url;

@end
